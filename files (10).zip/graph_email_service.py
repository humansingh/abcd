"""
Microsoft Graph API Email Service
Place at: app/services/graph_email_service.py

Sends emails via Microsoft Graph API using client credentials flow.
Used for analyst2 (live mode). Demo mode uses .eml downloads instead.

Required .env variables:
    GRAPH_TENANT_ID=5989ece0-f90e-40bf-9c79-1a7beccdb861
    GRAPH_CLIENT_ID=0f83c873-d8b7-48c5-8196-f4082c2441cb
    GRAPH_CLIENT_SECRET=4vR8Q~m5hpcGQgO8edAwtQkThMKhrnyLv9dDvakp
    GRAPH_SENDER_EMAIL=aman@iqvia.com   (the mailbox the app has Mail.Send on)

Permission required in Azure AD app registration:
    Microsoft Graph → Application permissions → Mail.Send

Testing: call test_graph_connection() to verify before first demo.
"""

import logging
from typing import List, Optional
import httpx

logger = logging.getLogger(__name__)

# ─── Token cache (in-memory, single process) ─────────────────────────────────
_token_cache: dict = {"access_token": None, "expires_at": 0}


async def _get_access_token(tenant_id: str, client_id: str, client_secret: str) -> str:
    """
    Fetch OAuth2 token using client credentials flow.
    Caches token in memory until ~5 minutes before expiry.
    """
    import time

    now = time.time()
    if _token_cache["access_token"] and now < _token_cache["expires_at"] - 300:
        return _token_cache["access_token"]

    url = f"https://login.microsoftonline.com/{tenant_id}/oauth2/v2.0/token"
    data = {
        "client_id": client_id,
        "client_secret": client_secret,
        "grant_type": "client_credentials",
        "scope": "https://graph.microsoft.com/.default",
    }

    async with httpx.AsyncClient(timeout=15) as client:
        response = await client.post(url, data=data)
        response.raise_for_status()
        token_data = response.json()

    _token_cache["access_token"] = token_data["access_token"]
    _token_cache["expires_at"] = now + token_data.get("expires_in", 3600)

    logger.info("Graph API: new access token obtained")
    return _token_cache["access_token"]


# ─── Send email ───────────────────────────────────────────────────────────────
async def send_email(
    subject: str,
    html_body: str,
    to_addresses: List[str],
    from_address: str,
    cc_addresses: Optional[List[str]] = None,
    save_to_sent: bool = False,
) -> bool:
    """
    Send an HTML email via Microsoft Graph API.

    Args:
        subject: Email subject line
        html_body: Full HTML body (inline styles for Outlook compatibility)
        to_addresses: List of recipient email addresses
        from_address: Sender email address (must have Mail.Send permission)
        cc_addresses: Optional CC list
        save_to_sent: Whether to save to Sent Items (default False for CI alerts)

    Returns:
        True on success, raises on failure
    """
    from config import settings

    tenant_id = getattr(settings, "GRAPH_TENANT_ID", None)
    client_id = getattr(settings, "GRAPH_CLIENT_ID", None)
    client_secret = getattr(settings, "GRAPH_CLIENT_SECRET", None)

    if not all([tenant_id, client_id, client_secret]):
        raise RuntimeError(
            "Graph API credentials not configured. "
            "Set GRAPH_TENANT_ID, GRAPH_CLIENT_ID, GRAPH_CLIENT_SECRET in .env"
        )

    token = await _get_access_token(tenant_id, client_id, client_secret)

    payload = {
        "message": {
            "subject": subject,
            "body": {
                "contentType": "HTML",
                "content": html_body,
            },
            "toRecipients": [
                {"emailAddress": {"address": addr}} for addr in to_addresses
            ],
            "from": {
                "emailAddress": {"address": from_address}
            },
        },
        "saveToSentItems": save_to_sent,
    }

    if cc_addresses:
        payload["message"]["ccRecipients"] = [
            {"emailAddress": {"address": addr}} for addr in cc_addresses
        ]

    # Graph API endpoint: send as the from_address user/mailbox
    url = f"https://graph.microsoft.com/v1.0/users/{from_address}/sendMail"

    async with httpx.AsyncClient(timeout=30) as client:
        response = await client.post(
            url,
            json=payload,
            headers={
                "Authorization": f"Bearer {token}",
                "Content-Type": "application/json",
            },
        )

    if response.status_code == 202:
        logger.info(f"Graph API: email sent — '{subject}' → {to_addresses}")
        return True
    else:
        error_detail = response.text[:500]
        logger.error(
            f"Graph API send failed: {response.status_code} — {error_detail}"
        )
        raise RuntimeError(
            f"Graph API send failed ({response.status_code}): {error_detail}"
        )


# ─── Connection test ──────────────────────────────────────────────────────────
async def test_graph_connection(from_address: str) -> dict:
    """
    Test Graph API connection without sending an email.
    Verifies token acquisition and mailbox access.

    Usage: GET /api/alerts/test-graph (analyst2 only)
    """
    from config import settings

    tenant_id = getattr(settings, "GRAPH_TENANT_ID", None)
    client_id = getattr(settings, "GRAPH_CLIENT_ID", None)
    client_secret = getattr(settings, "GRAPH_CLIENT_SECRET", None)

    results = {
        "credentials_configured": bool(tenant_id and client_id and client_secret),
        "token_acquired": False,
        "mailbox_accessible": False,
        "error": None,
    }

    if not results["credentials_configured"]:
        results["error"] = "GRAPH_TENANT_ID, GRAPH_CLIENT_ID, or GRAPH_CLIENT_SECRET missing from .env"
        return results

    try:
        token = await _get_access_token(tenant_id, client_id, client_secret)
        results["token_acquired"] = bool(token)
    except Exception as e:
        results["error"] = f"Token acquisition failed: {str(e)}"
        return results

    # Check mailbox is accessible
    try:
        url = f"https://graph.microsoft.com/v1.0/users/{from_address}/mailFolders/inbox"
        async with httpx.AsyncClient(timeout=15) as client:
            response = await client.get(
                url,
                headers={"Authorization": f"Bearer {token}"},
            )
        if response.status_code == 200:
            results["mailbox_accessible"] = True
        else:
            results["error"] = (
                f"Mailbox check returned {response.status_code}. "
                "Ensure Mail.Send application permission is granted in Azure AD."
            )
    except Exception as e:
        results["error"] = f"Mailbox check failed: {str(e)}"

    return results
