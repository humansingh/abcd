/**
 * projects.ts
 * Place at: src/constants/projects.ts
 *
 * Frontend mirror of app/config/projects.py
 * Drives: template preview style, colours, section labels, email subjects.
 *
 * Keep in sync with backend when adding new projects.
 */

export type TemplateStyle = 'ialert' | 'gsk' | 'jj';

export interface ProjectConfig {
  slug: string;
  projectName: string;
  clientName: string;
  templateStyle: TemplateStyle;
  primaryColor: string;
  secondaryColor: string;
  labelKeyTakeaways: string;
  labelImplications: string;
  labelBackground: string;
  implPlaceholder: string;   // label shown on "So What" / "Why important?" header
  greeting?: string;
  disclaimer?: string;
  implAudience?: string;
  subjectPrefix: string;
  // GSK only — paste base64 string here to preview with real header image in browser
  headerImageBase64?: string;
}

export const PROJECTS: Record<string, ProjectConfig> = {

  'autoantibody-cibi': {
    slug: 'autoantibody-cibi',
    projectName: 'AUTOANTIBODY CI/BI',
    clientName: 'AUTOANTIBODY',
    templateStyle: 'ialert',
    primaryColor: '#CC0000',
    secondaryColor: '#5A5A5A',
    labelKeyTakeaways: 'Key Takeaways',
    labelImplications: 'Why is this important?',
    labelBackground: 'Background',
    implPlaceholder: 'Why is this important?',
    subjectPrefix: 'AUTOANTIBODY CI/BI |',
  },

  'gsk-ci': {
    slug: 'gsk-ci',
    projectName: 'Global Competitive Intelligence',
    clientName: 'GSK',
    templateStyle: 'gsk',
    primaryColor: '#F26522',
    secondaryColor: '#F5F5F5',
    labelKeyTakeaways: 'Key Facts',
    labelImplications: 'So What',
    labelBackground: 'More Context',
    implPlaceholder: 'So What',
    greeting: 'Dear team,',
    subjectPrefix: 'GSK CI |',
    // headerImageBase64: 'PASTE_YOUR_BASE64_HERE',
  },

  'jj-ci': {
    slug: 'jj-ci',
    projectName: 'J&J CI Alert',
    clientName: 'J&J',
    templateStyle: 'jj',
    primaryColor: '#CC0000',
    secondaryColor: '#0066CC',
    labelKeyTakeaways: 'Key Takeaways',
    labelImplications: 'Key Implications',
    labelBackground: 'Summary',
    implPlaceholder: 'Key Implications',
    greeting: 'Dear all,',
    disclaimer: 'As a reminder, the views expressed in this Alert do not necessarily reflect the views of J&J.',
    implAudience: 'GCSO, EMEA',
    subjectPrefix: '[Draft] FW: CI Alert!',
  },
};

export const DEFAULT_PROJECT = PROJECTS['autoantibody-cibi'];

export function getProject(slug: string): ProjectConfig {
  return PROJECTS[slug] ?? DEFAULT_PROJECT;
}

export const PROJECT_OPTIONS = Object.values(PROJECTS).map((p) => ({
  value: p.slug,
  label: p.clientName,
}));
