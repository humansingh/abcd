/**
 * config.ts
 * Place at: src/lib/config.ts
 *
 * Central app configuration.
 * Set VITE_APP_URL in .env.local if Vite runs on a port other than 5173.
 *
 * Example .env.local:
 *   VITE_APP_URL=http://localhost:8080
 */

export const APP_URL: string =
  import.meta.env.VITE_APP_URL?.replace(/\/$/, '') ||
  `${window.location.protocol}//${window.location.hostname}:${window.location.port}` ||
  'http://localhost:5173';

export const API_BASE_URL: string =
  import.meta.env.VITE_API_URL?.replace(/\/$/, '') || 'http://localhost:8000';
