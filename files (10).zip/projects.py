"""
Project Configuration Registry
Place at: app/config/projects.py

Single source of truth for all CI Monitor projects.
Defines template style, colours, email settings, and section labels per project.

To add a new project:
  1. Add an entry to PROJECT_CONFIGS
  2. Create data/projects/{slug}/implications_context.md
  3. Add a frontend entry to src/constants/projects.ts
"""

from dataclasses import dataclass, field
from typing import Optional, List


@dataclass
class ProjectConfig:
    # Identity
    slug: str
    project_name: str           # Shown in grey bar / email subject
    client_name: str            # Short client label

    # Template
    template_style: str         # "ialert" | "gsk" | "jj"
    primary_color: str          # Main brand colour (header, section headers)
    secondary_color: str        # Secondary (grey bar for iAlert, body text)

    # Section labels (allow per-client customisation)
    label_key_takeaways: str = "Key Takeaways"
    label_implications: str = "Why is this important?"
    label_background: str = "Background"

    # J&J / GSK specifics
    implications_audience: Optional[str] = None   # e.g. "GCSO, EMEA"
    greeting: Optional[str] = None                # e.g. "Dear all,"
    disclaimer: Optional[str] = None             # Italic disclaimer paragraph

    # Email
    from_email: str = "aman@iqvia.com"
    to_email: str = "aman@iqvia.com"
    cc_emails: List[str] = field(default_factory=list)

    # Subject prefix convention
    subject_prefix: str = ""     # e.g. "[Draft] FW: CI Alert!" for J&J

    # GSK header image (base64 encoded PNG/JPG)
    # Instructions to populate:
    #   Python: import base64; print(base64.b64encode(open('gsk_header.png','rb').read()).decode())
    #   Node:   console.log(require('fs').readFileSync('gsk_header.png').toString('base64'))
    # Paste the output string below (no data URI prefix — just the raw base64)
    header_image_base64: Optional[str] = None
    header_image_mime: str = "image/png"   # "image/png" or "image/jpeg"


PROJECT_CONFIGS: dict[str, ProjectConfig] = {

    # ── iAlert — AUTOANTIBODY CI/BI ──────────────────────────────────────────
    "autoantibody-cibi": ProjectConfig(
        slug="autoantibody-cibi",
        project_name="AUTOANTIBODY CI/BI",
        client_name="AUTOANTIBODY",
        template_style="ialert",
        primary_color="#CC0000",
        secondary_color="#5A5A5A",
        label_key_takeaways="Key Takeaways",
        label_implications="Why is this important?",
        label_background="Background",
        from_email="aman@iqvia.com",
        to_email="aman@iqvia.com",
        subject_prefix="AUTOANTIBODY CI/BI |",
    ),

    # ── GSK — Global Competitive Intelligence ────────────────────────────────
    "gsk-ci": ProjectConfig(
        slug="gsk-ci",
        project_name="Global Competitive Intelligence",
        client_name="GSK",
        template_style="gsk",
        primary_color="#F26522",        # GSK orange
        secondary_color="#F5F5F5",
        label_key_takeaways="Key Facts",
        label_implications="So What",
        label_background="More Context",
        greeting="Dear team,",
        implications_audience=None,
        from_email="aman@iqvia.com",
        to_email="aman@iqvia.com",
        subject_prefix="GSK CI |",
        # header_image_base64="PASTE_YOUR_BASE64_STRING_HERE",
        header_image_base64=None,       # ← populate with base64 of gsk_header.png
        header_image_mime="image/png",
    ),

    # ── J&J — CI Alert ───────────────────────────────────────────────────────
    "jj-ci": ProjectConfig(
        slug="jj-ci",
        project_name="J&J CI Alert",
        client_name="J&J",
        template_style="jj",
        primary_color="#CC0000",        # J&J red
        secondary_color="#0066CC",      # link blue
        label_key_takeaways="Key Takeaways",
        label_implications="Key Implications",
        label_background="Summary",
        greeting="Dear all,",
        implications_audience="GCSO, EMEA",
        disclaimer=(
            "As a reminder, the views expressed in this Alert do not necessarily "
            "reflect the views of J&J."
        ),
        from_email="aman@iqvia.com",
        to_email="aman@iqvia.com",
        subject_prefix="[Draft] FW: CI Alert!",
    ),
}


def get_project(slug: str) -> ProjectConfig:
    """Return project config or raise ValueError for unknown slug."""
    if slug not in PROJECT_CONFIGS:
        raise ValueError(
            f"Unknown project slug: '{slug}'. "
            f"Valid slugs: {list(PROJECT_CONFIGS.keys())}"
        )
    return PROJECT_CONFIGS[slug]


def get_project_or_default(slug: str) -> ProjectConfig:
    """Return project config, falling back to autoantibody-cibi if unknown."""
    return PROJECT_CONFIGS.get(slug, PROJECT_CONFIGS["autoantibody-cibi"])
