/**
 * demoEml.ts
 * Place at: src/lib/demoEml.ts
 *
 * Builds and downloads the client template .eml file entirely in the browser.
 * Dispatches to the correct template renderer based on project slug.
 * No backend call needed — works fully offline for demo.
 */

import type { MockArticle } from '@/constants/mockArticles';
import { getProject, type ProjectConfig } from '@/constants/projects';

// ─── Types ────────────────────────────────────────────────────────────────────
interface BulletPoint {
  text: string;
  sub_bullets: string[];
}

interface AlertContent {
  news_class: string;
  key_takeaways: BulletPoint[];
  implications: BulletPoint[];
  background: BulletPoint[];
}

// ─── Shared helpers ───────────────────────────────────────────────────────────

function esc(s: string): string {
  return s
    .replace(/&/g, '&amp;').replace(/</g, '&lt;')
    .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function bulletsToHtml(bullets: BulletPoint[], fontSize = '13px'): string {
  if (!bullets?.length) return '<p style="color:#888;font-size:12px;font-style:italic;">Not generated.</p>';
  let html = '<ul style="margin:4px 0;padding-left:18px;list-style-type:disc;">';
  for (const b of bullets) {
    html += `<li style="margin-bottom:6px;font-size:${fontSize};line-height:1.55;color:#1a1a1a;">${esc(b.text)}`;
    if (b.sub_bullets?.length) {
      html += '<ul style="margin-top:4px;padding-left:18px;list-style-type:circle;">';
      for (const s of b.sub_bullets) {
        html += `<li style="margin-bottom:3px;font-size:12px;line-height:1.5;color:#333;">${esc(String(s))}</li>`;
      }
      html += '</ul>';
    }
    html += '</li>';
  }
  return html + '</ul>';
}

function bulletsPlain(bullets: BulletPoint[]): string {
  if (!bullets?.length) return '<p style="color:#888;font-style:italic;font-size:13px;">Not available.</p>';
  let html = '<ul style="margin:6px 0;padding-left:20px;">';
  for (const b of bullets) {
    html += `<li style="margin-bottom:7px;font-size:13px;line-height:1.6;color:#1a1a1a;">${esc(b.text)}`;
    if (b.sub_bullets?.length) {
      html += '<ul style="margin-top:3px;padding-left:18px;list-style-type:circle;">';
      for (const s of b.sub_bullets) {
        html += `<li style="margin-bottom:3px;font-size:12px;line-height:1.55;color:#333;">${esc(String(s))}</li>`;
      }
      html += '</ul>';
    }
    html += '</li>';
  }
  return html + '</ul>';
}

// ─── iAlert template ──────────────────────────────────────────────────────────

function renderIAlert(article: MockArticle, content: AlertContent, project: ProjectConfig): string {
  const RED = project.primaryColor;
  const GREY = project.secondaryColor;
  const src = `<a href="${esc(article.source_url)}" style="color:${RED};text-decoration:none;">${esc(article.source)}</a>`;

  const section = (label: string, html: string) => `
    <tr><td style="padding-top:6px;">
      <table width="100%" cellpadding="0" cellspacing="0">
        <tr><td style="background:${RED};padding:8px 20px;">
          <span style="color:white;font-weight:bold;font-size:13px;font-family:Arial,sans-serif;">${esc(label)}</span>
        </td></tr>
        <tr><td style="padding:12px 20px 14px;background:white;border-bottom:1px solid #f2f2f2;">${html}</td></tr>
      </table>
    </td></tr>`;

  return `<!DOCTYPE html><html><head><meta charset="UTF-8"><title>${esc(article.title)}</title></head>
<body style="margin:0;padding:0;background:#ffffff;font-family:Arial,Helvetica,sans-serif;">
<table width="650" cellpadding="0" cellspacing="0" border="0" style="margin:0 auto;background:#ffffff;border:1px solid #dddddd;">
  <tr><td style="padding:12px 20px;border-bottom:2px solid #f2f2f2;">
    <table width="100%" cellpadding="0" cellspacing="0"><tr>
      <td style="vertical-align:middle;width:56px;"><div style="background:${RED};padding:6px 8px;display:inline-block;"><span style="color:white;font-weight:900;font-size:13px;font-family:Arial,sans-serif;">iAlert</span></div></td>
      <td style="padding-left:10px;vertical-align:middle;"><div style="font-size:10px;color:#888;font-family:Arial,sans-serif;line-height:1.4;">Pharmaceutical Associates Ltd<br/>Competitive Intelligence &amp; Business Intelligence</div></td>
    </tr></table>
  </td></tr>
  <tr><td style="background:${GREY};padding:8px 20px;">
    <table width="100%" cellpadding="0" cellspacing="0"><tr>
      <td style="color:white;font-size:12px;font-weight:bold;letter-spacing:1.5px;text-transform:uppercase;font-family:Arial,sans-serif;">${esc(project.projectName)}</td>
      <td style="color:white;font-size:12px;font-weight:bold;text-align:right;text-transform:uppercase;font-family:Arial,sans-serif;">${esc(article.indication)}</td>
    </tr></table>
  </td></tr>
  <tr><td style="background:${RED};padding:14px 20px;">
    <table width="100%" cellpadding="0" cellspacing="0"><tr>
      <td style="color:white;font-size:14px;font-weight:bold;line-height:1.45;font-family:Arial,sans-serif;vertical-align:top;">${esc(article.title)}</td>
      <td style="color:white;font-size:12px;text-align:right;white-space:nowrap;vertical-align:top;padding-left:16px;font-family:Arial,sans-serif;">${esc(article.date)}</td>
    </tr></table>
  </td></tr>
  <tr><td style="padding:8px 20px 10px;font-size:12px;color:#444;font-family:Arial,sans-serif;border-bottom:1px solid #f2f2f2;">Source: ${src}</td></tr>
  ${section(project.labelKeyTakeaways, bulletsToHtml(content.key_takeaways))}
  ${section(project.labelImplications, bulletsToHtml(content.implications))}
  ${section(project.labelBackground, bulletsToHtml(content.background))}
  <tr><td style="padding:8px 20px 20px;font-size:12px;color:#444;font-family:Arial,sans-serif;border-top:1px solid #f2f2f2;">Source: ${src}</td></tr>
</table></body></html>`;
}

// ─── GSK template ─────────────────────────────────────────────────────────────

function renderGsk(article: MockArticle, content: AlertContent, project: ProjectConfig): string {
  const ORANGE = project.primaryColor;
  const src = `<a href="${esc(article.source_url)}" style="color:${ORANGE};text-decoration:underline;">${esc(article.source)}</a>`;

  const header = project.headerImageBase64
    ? `<tr><td><img src="data:image/png;base64,${project.headerImageBase64}" width="650" style="display:block;width:100%;border:0;" alt="GSK Global Competitive Intelligence" /></td></tr>`
    : `<tr><td style="background:${ORANGE};padding:28px 30px 24px;">
        <table width="100%" cellpadding="0" cellspacing="0"><tr>
          <td><div style="color:white;font-size:22px;font-weight:bold;font-family:Arial,sans-serif;">${esc(project.projectName)}</div>
          <div style="color:white;font-size:14px;font-family:Arial,sans-serif;margin-top:4px;">Specialty CI alert</div></td>
          <td style="text-align:right;width:80px;"><div style="color:white;font-size:24px;font-weight:900;font-family:Arial,sans-serif;">GSK</div></td>
        </tr></table>
      </td></tr>`;

  const box = (icon: string, title: string, html: string) => `
    <tr><td style="padding:0 20px;">
      <div style="border:1px solid #e8e8e8;border-radius:6px;background:white;margin-bottom:4px;overflow:hidden;">
        <table width="100%" cellpadding="0" cellspacing="0">
          <tr><td style="padding:16px 20px 8px;">
            <table cellpadding="0" cellspacing="0"><tr>
              <td style="vertical-align:middle;width:48px;padding-right:12px;">
                <table width="40" height="40" cellpadding="0" cellspacing="0" style="background:${ORANGE};border-radius:50%;"><tr>
                  <td style="text-align:center;vertical-align:middle;color:white;font-size:18px;">${icon}</td>
                </tr></table>
              </td>
              <td><span style="color:${ORANGE};font-size:18px;font-weight:bold;font-family:Arial,sans-serif;">${esc(title)}</span></td>
            </tr></table>
          </td></tr>
          <tr><td style="padding:4px 20px 16px;">${html}</td></tr>
        </table>
      </div>
    </td></tr>
    <tr><td style="padding:0 20px 10px;"><div style="border-top:1px solid ${ORANGE};"></div></td></tr>`;

  return `<!DOCTYPE html><html><head><meta charset="UTF-8"><title>${esc(article.title)}</title></head>
<body style="margin:0;padding:20px 0;background:#f5f5f5;font-family:Arial,Helvetica,sans-serif;">
<table width="650" cellpadding="0" cellspacing="0" border="0" style="margin:0 auto;background:#ffffff;border:1px solid #e0e0e0;">
  ${header}
  <tr><td style="padding:20px 24px 8px;background:white;">
    <p style="font-size:13px;color:#1a1a1a;margin:0 0 10px;">${esc(project.greeting || 'Dear team,')}</p>
    <p style="font-size:13px;color:#1a1a1a;line-height:1.65;margin:0 0 6px;">${esc(article.description || article.title)}</p>
    <p style="font-size:12px;color:#555;margin:0;">Source: ${src} &nbsp;·&nbsp; ${esc(article.date)}</p>
  </td></tr>
  <tr><td style="padding:12px 20px;"><div style="border-top:1px solid ${ORANGE};"></div></td></tr>
  ${box('?', project.labelImplications, bulletsToHtml(content.implications))}
  ${box('&#128273;', project.labelKeyTakeaways, bulletsToHtml(content.key_takeaways))}
  <tr><td style="padding:0 20px;">
    <div style="border:1px solid #e8e8e8;border-radius:6px;background:white;margin-bottom:4px;overflow:hidden;">
      <table width="100%" cellpadding="0" cellspacing="0">
        <tr><td style="padding:16px 20px 8px;">
          <table cellpadding="0" cellspacing="0"><tr>
            <td style="vertical-align:middle;width:48px;padding-right:12px;">
              <table width="40" height="40" cellpadding="0" cellspacing="0" style="background:${ORANGE};border-radius:50%;"><tr>
                <td style="text-align:center;vertical-align:middle;color:white;font-size:18px;">&#9741;</td>
              </tr></table>
            </td>
            <td><span style="color:${ORANGE};font-size:18px;font-weight:bold;font-family:Arial,sans-serif;">Sources</span></td>
          </tr></table>
        </td></tr>
        <tr><td style="padding:4px 20px 16px;"><ul style="margin:0;padding-left:18px;font-size:13px;"><li>${src}</li></ul></td></tr>
      </table>
    </div>
  </td></tr>
  <tr><td style="padding:0 20px 10px;"><div style="border-top:1px solid ${ORANGE};"></div></td></tr>
  ${box('&#128161;', project.labelBackground, bulletsToHtml(content.background))}
  <tr><td style="background:${ORANGE};padding:14px 24px;">
    <table width="100%" cellpadding="0" cellspacing="0"><tr>
      <td><p style="color:white;font-size:10px;margin:0;line-height:1.6;font-family:Arial,sans-serif;">GCI distribution lists protect GCI of our assets and are restricted to senior leadership and MCTs/MDTs.<br/><em>For internal use only; not to be shared externally.</em></p></td>
      <td style="text-align:right;padding-left:12px;width:40px;"><span style="font-size:22px;color:white;">&#128269;</span></td>
    </tr></table>
  </td></tr>
</table></body></html>`;
}

// ─── J&J template ─────────────────────────────────────────────────────────────

function renderJj(article: MockArticle, content: AlertContent, project: ProjectConfig): string {
  const RED = project.primaryColor;
  const BLUE = project.secondaryColor;
  const src = `<a href="${esc(article.source_url)}" style="color:${BLUE};text-decoration:underline;">${esc(article.source)}, ${esc(article.date)}</a>`;
  const impLabel = project.implAudience
    ? `${project.labelImplications} (for ${project.implAudience})`
    : project.labelImplications;

  const section = (label: string, html: string) => `
    <tr><td style="padding:0 0 12px;">
      <p style="font-size:14px;font-weight:bold;color:${BLUE};text-decoration:underline;margin:0 0 6px;font-family:Calibri,Arial,sans-serif;">${esc(label)}</p>
      ${html}
    </td></tr>
    <tr><td style="padding:0 0 12px;"><div style="border-top:1px solid #cccccc;"></div></td></tr>`;

  return `<!DOCTYPE html><html><head><meta charset="UTF-8"><title>${esc(article.title)}</title></head>
<body style="margin:0;padding:20px;background:#ffffff;font-family:Calibri,Arial,sans-serif;">
<table width="650" cellpadding="0" cellspacing="0" border="0" style="margin:0 auto;background:#ffffff;">
  <tr><td style="padding:0 0 10px;">
    <p style="font-size:13px;color:#1a1a1a;margin:0 0 10px;">${esc(project.greeting || 'Dear all,')}</p>
    <p style="font-size:13px;color:#1a1a1a;margin:0 0 10px;">Please see the summary of the news below.</p>
    ${project.disclaimer ? `<p style="font-size:13px;color:#333;font-style:italic;margin:0 0 10px;">${esc(project.disclaimer)}</p>` : ''}
    <p style="font-size:13px;color:#333;font-style:italic;margin:0 0 14px;line-height:1.6;">
      The below Alert! is a summary of &ldquo;${esc(article.title)}&rdquo; based on the following source: ${src}
    </p>
  </td></tr>
  <tr><td style="padding:0 0 14px;">
    <p style="font-size:14px;font-weight:bold;color:${RED};margin:0;line-height:1.4;">
      <a href="${esc(article.source_url)}" style="color:${RED};text-decoration:underline;">${esc(article.title)}</a>
    </p>
  </td></tr>
  <tr><td style="padding:0 0 14px;"><div style="border-top:1px solid #cccccc;"></div></td></tr>
  ${section(project.labelKeyTakeaways, bulletsPlain(content.key_takeaways))}
  ${section(impLabel, bulletsPlain(content.implications))}
  ${section(project.labelBackground, bulletsPlain(content.background))}
  <tr><td style="padding:0 0 20px;"><p style="font-size:12px;color:#555;margin:0;">Source: ${src}</p></td></tr>
</table></body></html>`;
}

// ─── EML builder + download ───────────────────────────────────────────────────

function buildEmlSubject(article: MockArticle, project: ProjectConfig): string {
  const short = article.title.length > 80 ? article.title.slice(0, 77) + '...' : article.title;
  return `${project.subjectPrefix} ${article.indication} | ${short} — ${article.date}`;
}

export function buildDemoEml(article: MockArticle, content: AlertContent, projectSlug = 'autoantibody-cibi'): void {
  const project = getProject(projectSlug);

  let html: string;
  if (project.templateStyle === 'gsk') {
    html = renderGsk(article, content, project);
  } else if (project.templateStyle === 'jj') {
    html = renderJj(article, content, project);
  } else {
    html = renderIAlert(article, content, project);
  }

  const subject = buildEmlSubject(article, project);

  const eml = [
    `From: aman@iqvia.com`,
    `To: aman@iqvia.com`,
    `Subject: ${subject}`,
    `MIME-Version: 1.0`,
    `Content-Type: text/html; charset=UTF-8`,
    `Content-Transfer-Encoding: 7bit`,
    `X-Mailer: CI Monitor`,
    ``,
    html,
  ].join('\r\n');

  const blob = new Blob([eml], { type: 'message/rfc822' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  const safeTitle = article.title.replace(/[^a-zA-Z0-9 _-]/g, '').trim().slice(0, 40).replace(/ /g, '_');
  a.download = `CI_Alert_${article.indication}_${safeTitle}.eml`;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
