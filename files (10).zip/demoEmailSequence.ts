/**
 * demoEmailSequence.ts
 * Place at: src/lib/demoEmailSequence.ts
 *
 * Generates and downloads all session emails in demo mode.
 * Uses APP_URL from config.ts so it works on any Vite port (5173, 8080, etc.)
 */

import type { MockArticle } from '@/constants/mockArticles';
import { APP_URL } from '@/lib/config';

function esc(str: string): string {
  return str
    .replace(/&/g, '&amp;').replace(/</g, '&lt;')
    .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function downloadEml(filename: string, subject: string, htmlBody: string): void {
  const eml = [
    `From: aman@iqvia.com`,
    `To: aman@iqvia.com`,
    `Subject: ${subject}`,
    `MIME-Version: 1.0`,
    `Content-Type: text/html; charset=UTF-8`,
    `Content-Transfer-Encoding: 7bit`,
    `X-Mailer: CI Monitor`,
    ``,
    htmlBody,
  ].join('\r\n');

  const blob = new Blob([eml], { type: 'message/rfc822' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function buildJobCompleteHtml(articles: MockArticle[], sessionId: string): string {
  const highCount = articles.filter((a) => a.priority === 'high').length;
  const NAVY = '#004B8D';
  return `<!DOCTYPE html><html><head><meta charset="UTF-8"></head>
<body style="margin:0;padding:0;background:#f4f6f9;font-family:Arial,Helvetica,sans-serif;">
<table width="580" cellpadding="0" cellspacing="0" style="margin:0 auto;background:white;border:1px solid #dde3ea;">
  <tr><td style="background:${NAVY};padding:14px 24px;">
    <table width="100%" cellpadding="0" cellspacing="0"><tr>
      <td style="color:white;font-size:16px;font-weight:bold;">CI Monitor</td>
      <td style="color:rgba(255,255,255,0.7);font-size:11px;text-align:right;">Session Complete</td>
    </tr></table>
  </td></tr>
  <tr><td style="padding:24px 24px 10px;">
    <div style="font-size:18px;font-weight:bold;color:#1a1a1a;">Scraping session complete</div>
    <div style="font-size:13px;color:#666;margin-top:4px;">Demo Session ${sessionId}</div>
  </td></tr>
  <tr><td style="padding:10px 24px 20px;">
    <table width="100%" cellpadding="0" cellspacing="0" style="background:#E6F2FF;border-radius:6px;"><tr>
      <td style="padding:14px 20px;text-align:center;border-right:1px solid #c8dff5;">
        <div style="font-size:28px;font-weight:bold;color:${NAVY};">${articles.length}</div>
        <div style="font-size:11px;color:#555;margin-top:2px;">Total Articles</div>
      </td>
      <td style="padding:14px 20px;text-align:center;border-right:1px solid #c8dff5;">
        <div style="font-size:28px;font-weight:bold;color:#CC0000;">${highCount}</div>
        <div style="font-size:11px;color:#555;margin-top:2px;">High Priority</div>
      </td>
      <td style="padding:14px 20px;text-align:center;">
        <div style="font-size:18px;font-weight:bold;color:#28A745;">2m 34s</div>
        <div style="font-size:11px;color:#555;margin-top:2px;">Duration</div>
      </td>
    </tr></table>
  </td></tr>
  <tr><td style="padding:0 24px 24px;">
    <a href="${APP_URL}/articles" style="display:inline-block;background:${NAVY};color:white;font-size:13px;font-weight:bold;padding:10px 22px;border-radius:4px;text-decoration:none;">View Articles →</a>
  </td></tr>
  <tr><td style="background:#f4f6f9;padding:10px 24px;border-top:1px solid #dde3ea;font-size:10px;color:#999;text-align:center;">CI Monitor · Automated Competitive Intelligence</td></tr>
</table></body></html>`;
}

function buildSummaryHtml(articles: MockArticle[], sessionId: string): string {
  const NAVY = '#004B8D';
  const RED = '#CC0000';
  const highArticles = articles.filter((a) => a.priority === 'high');

  const rows = highArticles.map((a, i) =>
    `<tr style="background:${i % 2 === 1 ? '#f8f9fa' : 'white'};">
      <td style="padding:8px 12px;border-left:3px solid ${RED};">
        <div style="font-size:12px;font-weight:bold;color:#1a1a1a;">${esc(a.title)}</div>
        <div style="font-size:11px;color:#666;margin-top:2px;">
          ${esc(a.indication)} · ${esc(a.source)} · ${esc(a.date)}
          &nbsp;·&nbsp; <a href="${esc(a.source_url)}" style="color:${NAVY};">Source ↗</a>
        </div>
      </td></tr>`
  ).join('');

  return `<!DOCTYPE html><html><head><meta charset="UTF-8"></head>
<body style="margin:0;padding:0;background:#f4f6f9;font-family:Arial,Helvetica,sans-serif;">
<table width="620" cellpadding="0" cellspacing="0" style="margin:0 auto;background:white;border:1px solid #dde3ea;">
  <tr><td style="background:${NAVY};padding:14px 20px;">
    <table width="100%" cellpadding="0" cellspacing="0"><tr>
      <td style="color:white;font-size:16px;font-weight:bold;">CI Monitor</td>
      <td style="color:rgba(255,255,255,0.7);font-size:11px;text-align:right;">Session Summary</td>
    </tr></table>
  </td></tr>
  <tr><td style="padding:16px 20px 8px;">
    <div style="font-size:15px;font-weight:bold;color:#1a1a1a;">Demo Session ${sessionId}</div>
    <div style="font-size:12px;color:#666;margin-top:2px;">
      ${articles.length} articles &nbsp;·&nbsp;
      <span style="color:${RED};font-weight:bold;">${highArticles.length} high priority</span>
    </div>
  </td></tr>
  <tr><td style="padding:4px 20px 2px;font-size:11px;font-weight:bold;color:${RED};text-transform:uppercase;letter-spacing:0.5px;">High Priority Articles</td></tr>
  <tr><td style="padding:0 20px 12px;"><table width="100%" cellpadding="0" cellspacing="4">${rows}</table></td></tr>
  <tr><td style="padding:0 20px 20px;">
    <a href="${APP_URL}/articles?session=${sessionId}" style="display:inline-block;background:${NAVY};color:white;font-size:13px;font-weight:bold;padding:10px 22px;border-radius:4px;text-decoration:none;">Review All Articles →</a>
  </td></tr>
  <tr><td style="background:#f4f6f9;padding:10px 20px;border-top:1px solid #dde3ea;font-size:10px;color:#999;text-align:center;">CI Monitor · Session ID ${sessionId}</td></tr>
</table></body></html>`;
}

function buildArticleAlertHtml(article: MockArticle): string {
  const NAVY = '#004B8D';
  const RED = '#CC0000';
  const GREEN = '#28A745';
  const approveUrl = `${APP_URL}/articles?action=approve&id=${article.id}`;
  const rejectUrl = `${APP_URL}/articles?action=reject&id=${article.id}`;
  const prepareUrl = `${APP_URL}/articles?action=prepare&id=${article.id}`;

  return `<!DOCTYPE html><html><head><meta charset="UTF-8"></head>
<body style="margin:0;padding:0;background:#f4f6f9;font-family:Arial,Helvetica,sans-serif;">
<table width="620" cellpadding="0" cellspacing="0" style="margin:0 auto;background:white;border:1px solid #dde3ea;">
  <tr><td style="background:${NAVY};padding:14px 20px;">
    <table width="100%" cellpadding="0" cellspacing="0"><tr>
      <td style="color:white;font-size:16px;font-weight:bold;">CI Monitor</td>
      <td style="color:rgba(255,255,255,0.7);font-size:11px;text-align:right;">Competitive Intelligence Alert</td>
    </tr></table>
  </td></tr>
  <tr><td style="padding:10px 20px;background:#E6F2FF;border-bottom:2px solid ${NAVY};">
    <span style="background:${RED};color:white;font-size:10px;font-weight:bold;padding:3px 8px;border-radius:3px;">HIGH PRIORITY</span>
    <span style="background:${NAVY};color:white;font-size:10px;font-weight:bold;padding:3px 8px;border-radius:3px;margin-left:6px;">${esc(article.indication)}</span>
    <span style="color:#555;font-size:11px;margin-left:8px;">${esc(article.region)}</span>
    <span style="float:right;font-size:11px;color:#666;">${esc(article.date)}</span>
  </td></tr>
  <tr><td style="padding:16px 20px 10px;">
    <div style="font-size:16px;font-weight:bold;color:#1a1a1a;line-height:1.4;">${esc(article.title)}</div>
    <div style="font-size:12px;color:#666;margin-top:5px;">Source: <a href="${esc(article.source_url)}" style="color:${NAVY};">${esc(article.source)}</a></div>
  </td></tr>
  <tr><td style="padding:4px 20px 10px;font-size:11px;color:#555;">
    <b>Companies:</b> ${esc(article.companies_mentioned.join(', ') || '—')} &nbsp;·&nbsp; <b>Assets:</b> ${esc(article.drug_names_mentioned.join(', ') || '—')}
  </td></tr>
  <tr><td style="padding:0 20px;"><div style="border-top:1px solid #eee;"></div></td></tr>
  <tr><td style="padding:12px 20px 14px;">
    <div style="font-size:12px;font-weight:bold;color:${NAVY};text-transform:uppercase;letter-spacing:0.5px;margin-bottom:6px;">Summary</div>
    <div style="font-size:13px;color:#333;line-height:1.6;">${esc(article.description || article.title)}</div>
  </td></tr>
  <tr><td style="padding:0 20px;"><div style="border-top:1px solid #eee;"></div></td></tr>
  <tr><td style="padding:16px 20px 20px;">
    <div style="font-size:12px;color:#666;margin-bottom:10px;">Take action on this article:</div>
    <table cellpadding="0" cellspacing="0"><tr>
      <td style="padding-right:8px;"><a href="${approveUrl}" style="display:inline-block;background:${GREEN};color:white;font-size:12px;font-weight:bold;padding:9px 18px;border-radius:4px;text-decoration:none;">&#10003; Approve</a></td>
      <td style="padding-right:8px;"><a href="${rejectUrl}" style="display:inline-block;background:#6c757d;color:white;font-size:12px;font-weight:bold;padding:9px 18px;border-radius:4px;text-decoration:none;">&#10007; Reject</a></td>
      <td><a href="${prepareUrl}" style="display:inline-block;background:${RED};color:white;font-size:12px;font-weight:bold;padding:9px 18px;border-radius:4px;text-decoration:none;">Prepare Client Template &#8594;</a></td>
    </tr></table>
  </td></tr>
  <tr><td style="background:#f4f6f9;padding:10px 20px;border-top:1px solid #dde3ea;font-size:10px;color:#999;text-align:center;">CI Monitor · Article ID: ${article.id} · Review before forwarding to clients.</td></tr>
</table></body></html>`;
}

export async function buildDemoEmailSequence(
  articles: MockArticle[],
  sessionId: string,
): Promise<void> {
  const highArticles = articles.filter((a) => a.priority === 'high');

  downloadEml(
    'job_complete.eml',
    `[CI Monitor] Session Complete — Demo Session ${sessionId} | ${articles.length} articles (${highArticles.length} high)`,
    buildJobCompleteHtml(articles, sessionId),
  );
  await new Promise((r) => setTimeout(r, 300));

  downloadEml(
    'summary.eml',
    `[CI Monitor] Session Summary — ${highArticles.length} high priority | Demo Session ${sessionId}`,
    buildSummaryHtml(articles, sessionId),
  );
  await new Promise((r) => setTimeout(r, 300));

  for (const article of highArticles) {
    const short = article.title.length > 90 ? article.title.slice(0, 87) + '...' : article.title;
    downloadEml(
      `article_${article.id}_${article.indication}.eml`,
      `[HIGH] ${article.indication} | ${short}`,
      buildArticleAlertHtml(article),
    );
    await new Promise((r) => setTimeout(r, 250));
  }
}
