"""
Template Service — Multi-Project HTML Builder
Place at: app/services/template_service.py

Three client template renderers:
  ialert  — red/grey iAlert style  (AUTOANTIBODY CI/BI)
  gsk     — orange GSK CI style    (GSK)
  jj      — plain Word-doc style   (J&J)

All renderers accept the same content structure and ProjectConfig,
keeping the AI layer fully decoupled from presentation.
"""

from typing import List, Optional
from html import escape


# ─── Shared helpers ───────────────────────────────────────────────────────────

def _bullets_to_html(bullets: List[dict], font_size: str = "13px") -> str:
    if not bullets:
        return "<p style='color:#888;font-size:12px;font-style:italic;'>Content not yet generated.</p>"
    html = '<ul style="margin:4px 0;padding-left:18px;list-style-type:disc;">'
    for b in bullets:
        text = escape(b.get("text", ""))
        subs = b.get("sub_bullets", [])
        html += f'<li style="margin-bottom:6px;font-size:{font_size};line-height:1.55;color:#1a1a1a;">{text}'
        if subs:
            html += '<ul style="margin-top:4px;padding-left:18px;list-style-type:circle;">'
            for s in subs:
                html += f'<li style="margin-bottom:3px;font-size:12px;line-height:1.5;color:#333;">{escape(str(s))}</li>'
            html += "</ul>"
        html += "</li>"
    html += "</ul>"
    return html


def _bullets_plain(bullets: List[dict]) -> str:
    """Plain bullet style for J&J (standard Outlook aesthetic)."""
    if not bullets:
        return "<p style='color:#888;font-style:italic;font-size:13px;'>Not available.</p>"
    html = '<ul style="margin:6px 0;padding-left:20px;">'
    for b in bullets:
        text = escape(b.get("text", ""))
        subs = b.get("sub_bullets", [])
        html += f'<li style="margin-bottom:7px;font-size:13px;line-height:1.6;color:#1a1a1a;">{text}'
        if subs:
            html += '<ul style="margin-top:3px;padding-left:18px;list-style-type:circle;">'
            for s in subs:
                html += f'<li style="margin-bottom:3px;font-size:12px;line-height:1.55;color:#333;">{escape(str(s))}</li>'
            html += "</ul>"
        html += "</li>"
    html += "</ul>"
    return html


# ─── iAlert renderer ──────────────────────────────────────────────────────────

def _render_ialert(headline, date, source_name, source_url, indication,
                   project_name, key_takeaways, implications, background,
                   primary_color="#CC0000", secondary_color="#5A5A5A",
                   label_kt="Key Takeaways", label_imp="Why is this important?",
                   label_bg="Background") -> str:
    RED, GREY = primary_color, secondary_color
    kt = _bullets_to_html(key_takeaways)
    imp = _bullets_to_html(implications)
    bg = _bullets_to_html(background)
    src = f'<a href="{source_url}" style="color:{RED};text-decoration:none;">{escape(source_name)}</a>'

    def section(label, content):
        return f"""<tr><td style="padding-top:6px;">
    <table width="100%" cellpadding="0" cellspacing="0">
      <tr><td style="background:{RED};padding:8px 20px;">
        <span style="color:white;font-weight:bold;font-size:13px;font-family:Arial,sans-serif;">{escape(label)}</span>
      </td></tr>
      <tr><td style="padding:12px 20px 14px;background:white;border-bottom:1px solid #f2f2f2;">{content}</td></tr>
    </table></td></tr>"""

    return f"""<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><title>{escape(headline)}</title></head>
<body style="margin:0;padding:0;background:#ffffff;font-family:Arial,Helvetica,sans-serif;">
<table width="650" cellpadding="0" cellspacing="0" border="0" style="margin:0 auto;background:#ffffff;border:1px solid #dddddd;">
  <tr><td style="padding:12px 20px;border-bottom:2px solid #f2f2f2;">
    <table width="100%" cellpadding="0" cellspacing="0"><tr>
      <td style="vertical-align:middle;width:56px;">
        <div style="background:{RED};padding:6px 8px;display:inline-block;">
          <span style="color:white;font-weight:900;font-size:13px;font-family:Arial,sans-serif;">iAlert</span>
        </div>
      </td>
      <td style="padding-left:10px;vertical-align:middle;">
        <div style="font-size:10px;color:#888;font-family:Arial,sans-serif;line-height:1.4;">
          Pharmaceutical Associates Ltd<br/>Competitive Intelligence &amp; Business Intelligence
        </div>
      </td>
    </tr></table>
  </td></tr>
  <tr><td style="background:{GREY};padding:8px 20px;">
    <table width="100%" cellpadding="0" cellspacing="0"><tr>
      <td style="color:white;font-size:12px;font-weight:bold;letter-spacing:1.5px;text-transform:uppercase;font-family:Arial,sans-serif;">{escape(project_name)}</td>
      <td style="color:white;font-size:12px;font-weight:bold;text-align:right;text-transform:uppercase;font-family:Arial,sans-serif;">{escape(indication)}</td>
    </tr></table>
  </td></tr>
  <tr><td style="background:{RED};padding:14px 20px;">
    <table width="100%" cellpadding="0" cellspacing="0"><tr>
      <td style="color:white;font-size:14px;font-weight:bold;line-height:1.45;font-family:Arial,sans-serif;vertical-align:top;">{escape(headline)}</td>
      <td style="color:white;font-size:12px;text-align:right;white-space:nowrap;vertical-align:top;padding-left:16px;font-family:Arial,sans-serif;">{escape(date)}</td>
    </tr></table>
  </td></tr>
  <tr><td style="padding:8px 20px 10px;font-size:12px;color:#444;font-family:Arial,sans-serif;border-bottom:1px solid #f2f2f2;">Source: {src}</td></tr>
  {section(label_kt, kt)}
  {section(label_imp, imp)}
  {section(label_bg, bg)}
  <tr><td style="padding:8px 20px 20px;font-size:12px;color:#444;font-family:Arial,sans-serif;border-top:1px solid #f2f2f2;">Source: {src}</td></tr>
</table></body></html>"""


# ─── GSK renderer ─────────────────────────────────────────────────────────────

def _render_gsk(headline, date, source_name, source_url, indication,
                project_name, key_takeaways, implications, background,
                description="", greeting="Dear team,",
                primary_color="#F26522", label_kt="Key Facts",
                label_imp="So What", label_bg="More Context",
                header_image_base64=None, header_image_mime="image/png") -> str:
    """
    GSK orange branded template.

    Header image setup:
      1. Run: python -c "import base64; print(base64.b64encode(open('gsk_header.png','rb').read()).decode())"
      2. In app/config/projects.py, set:
            header_image_base64="<paste output here>",
            header_image_mime="image/png",
      3. Redeploy — image embeds inline in every .eml, no external URL needed.

    Until populated, renders a matching HTML fallback header.
    """
    ORANGE = primary_color
    src = f'<a href="{source_url}" style="color:{ORANGE};text-decoration:underline;">{escape(source_name)}</a>'

    # Header: image embed or HTML fallback
    if header_image_base64 and header_image_base64 not in ("PASTE_YOUR_BASE64_STRING_HERE", None):
        header = f"""<tr><td style="padding:0;margin:0;">
    <img src="data:{header_image_mime};base64,{header_image_base64}"
         width="650" style="display:block;width:100%;max-width:650px;border:0;"
         alt="GSK Global Competitive Intelligence" />
  </td></tr>"""
    else:
        header = f"""<tr><td style="background:{ORANGE};padding:28px 30px 24px;">
    <table width="100%" cellpadding="0" cellspacing="0"><tr>
      <td style="vertical-align:top;">
        <div style="color:white;font-size:22px;font-weight:bold;font-family:Arial,sans-serif;line-height:1.2;">{escape(project_name)}</div>
        <div style="color:white;font-size:14px;font-family:Arial,sans-serif;margin-top:4px;opacity:0.9;">Specialty CI alert</div>
      </td>
      <td style="text-align:right;vertical-align:top;padding-left:20px;width:80px;">
        <div style="color:white;font-size:24px;font-weight:900;font-family:Arial,sans-serif;letter-spacing:-1px;">GSK</div>
      </td>
    </tr></table>
  </td></tr>"""

    def section_box(icon, title, content_html):
        return f"""<tr><td style="padding:0 20px;">
    <div style="border:1px solid #e8e8e8;border-radius:6px;background:white;margin-bottom:4px;overflow:hidden;">
      <table width="100%" cellpadding="0" cellspacing="0">
        <tr><td style="padding:16px 20px 8px;">
          <table cellpadding="0" cellspacing="0"><tr>
            <td style="vertical-align:middle;width:48px;padding-right:12px;">
              <table width="40" height="40" cellpadding="0" cellspacing="0"
                style="background:{ORANGE};border-radius:50%;"><tr>
                <td style="text-align:center;vertical-align:middle;font-size:20px;color:white;">{icon}</td>
              </tr></table>
            </td>
            <td style="vertical-align:middle;">
              <span style="color:{ORANGE};font-size:18px;font-weight:bold;font-family:Arial,sans-serif;">{escape(title)}</span>
            </td>
          </tr></table>
        </td></tr>
        <tr><td style="padding:4px 20px 16px;">{content_html}</td></tr>
      </table>
    </div>
  </td></tr>
  <tr><td style="padding:0 20px 10px;"><div style="border-top:1px solid {ORANGE};"></div></td></tr>"""

    kt = _bullets_to_html(key_takeaways)
    imp = _bullets_to_html(implications)
    bg = _bullets_to_html(background)

    sources_box = f"""<tr><td style="padding:0 20px;">
    <div style="border:1px solid #e8e8e8;border-radius:6px;background:white;margin-bottom:4px;overflow:hidden;">
      <table width="100%" cellpadding="0" cellspacing="0">
        <tr><td style="padding:16px 20px 8px;">
          <table cellpadding="0" cellspacing="0"><tr>
            <td style="vertical-align:middle;width:48px;padding-right:12px;">
              <table width="40" height="40" cellpadding="0" cellspacing="0"
                style="background:{ORANGE};border-radius:50%;"><tr>
                <td style="text-align:center;vertical-align:middle;font-size:18px;color:white;">&#9741;</td>
              </tr></table>
            </td>
            <td style="vertical-align:middle;">
              <span style="color:{ORANGE};font-size:18px;font-weight:bold;font-family:Arial,sans-serif;">Sources</span>
            </td>
          </tr></table>
        </td></tr>
        <tr><td style="padding:4px 20px 16px;">
          <ul style="margin:0;padding-left:18px;font-size:13px;color:#1a1a1a;">
            <li style="margin-bottom:4px;">{src}</li>
          </ul>
        </td></tr>
      </table>
    </div>
  </td></tr>
  <tr><td style="padding:0 20px 10px;"><div style="border-top:1px solid {ORANGE};"></div></td></tr>"""

    return f"""<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><title>{escape(headline)}</title></head>
<body style="margin:0;padding:20px 0;background:#f5f5f5;font-family:Arial,Helvetica,sans-serif;">
<table width="650" cellpadding="0" cellspacing="0" border="0"
  style="margin:0 auto;background:#ffffff;border:1px solid #e0e0e0;">
  {header}
  <tr><td style="padding:20px 24px 8px;background:white;">
    <p style="font-size:13px;color:#1a1a1a;margin:0 0 10px;">{escape(greeting)}</p>
    <p style="font-size:13px;color:#1a1a1a;line-height:1.65;margin:0 0 6px;">{escape(description or headline)}</p>
    <p style="font-size:12px;color:#555;margin:0;">Source: {src} &nbsp;·&nbsp; {escape(date)}</p>
  </td></tr>
  <tr><td style="padding:12px 20px;"><div style="border-top:1px solid {ORANGE};"></div></td></tr>
  {section_box("?", label_imp, imp)}
  {section_box("&#128273;", label_kt, kt)}
  {sources_box}
  {section_box("&#128161;", label_bg, bg)}
  <tr><td style="background:{ORANGE};padding:14px 24px;">
    <table width="100%" cellpadding="0" cellspacing="0"><tr>
      <td style="vertical-align:middle;">
        <p style="color:white;font-size:10px;margin:0;line-height:1.6;font-family:Arial,sans-serif;">
          GCI distribution lists protect GCI of our assets and are restricted to senior leadership and MCTs/MDTs.<br/>
          <em>For internal use only; not to be shared externally. Please exercise discretion if forwarding internally.</em>
        </p>
      </td>
      <td style="text-align:right;padding-left:12px;width:40px;">
        <span style="font-size:22px;color:white;">&#128269;</span>
      </td>
    </tr></table>
  </td></tr>
</table></body></html>"""


# ─── J&J renderer ─────────────────────────────────────────────────────────────

def _render_jj(headline, date, source_name, source_url, indication,
               project_name, key_takeaways, implications, background,
               greeting="Dear all,", disclaimer=None,
               implications_audience=None, primary_color="#CC0000",
               link_color="#0066CC", label_kt="Key Takeaways",
               label_imp="Key Implications", label_bg="Summary") -> str:
    RED, BLUE = primary_color, link_color
    kt = _bullets_plain(key_takeaways)
    imp = _bullets_plain(implications)
    bg = _bullets_plain(background)

    src = f'<a href="{source_url}" style="color:{BLUE};text-decoration:underline;">{escape(source_name)}, {escape(date)}</a>'
    imp_label = f"{label_imp} (for {implications_audience})" if implications_audience else label_imp

    disclaimer_html = (
        f'<p style="font-size:13px;color:#333;font-style:italic;margin:0 0 10px;">{escape(disclaimer)}</p>'
        if disclaimer else ""
    )

    def section(label, content):
        return f"""<tr><td style="padding:0 0 12px;">
    <p style="font-size:14px;font-weight:bold;color:{BLUE};text-decoration:underline;
       margin:0 0 6px;font-family:Calibri,Arial,sans-serif;">{escape(label)}</p>
    {content}
  </td></tr>
  <tr><td style="padding:0 0 12px;"><div style="border-top:1px solid #cccccc;"></div></td></tr>"""

    return f"""<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><title>{escape(headline)}</title></head>
<body style="margin:0;padding:20px;background:#ffffff;font-family:Calibri,Arial,sans-serif;">
<table width="650" cellpadding="0" cellspacing="0" border="0" style="margin:0 auto;background:#ffffff;">
  <tr><td style="padding:0 0 10px;">
    <p style="font-size:13px;color:#1a1a1a;margin:0 0 10px;">{escape(greeting)}</p>
    <p style="font-size:13px;color:#1a1a1a;margin:0 0 10px;">Please see the summary of the news below.</p>
    {disclaimer_html}
    <p style="font-size:13px;color:#333;font-style:italic;margin:0 0 14px;line-height:1.6;">
      The below Alert! is a summary of &ldquo;{escape(headline)}&rdquo; based on the following source: {src}
    </p>
  </td></tr>
  <tr><td style="padding:0 0 14px;">
    <p style="font-size:14px;font-weight:bold;color:{RED};margin:0;line-height:1.4;">
      <a href="{source_url}" style="color:{RED};text-decoration:underline;">{escape(headline)}</a>
    </p>
  </td></tr>
  <tr><td style="padding:0 0 14px;"><div style="border-top:1px solid #cccccc;"></div></td></tr>
  {section(label_kt, kt)}
  {section(imp_label, imp)}
  {section(label_bg, bg)}
  <tr><td style="padding:0 0 20px;">
    <p style="font-size:12px;color:#555;margin:0;">Source: {src}</p>
  </td></tr>
</table></body></html>"""


# ─── Public dispatcher ────────────────────────────────────────────────────────

def build_client_template_html(
    headline: str, date: str, source_name: str, source_url: str,
    indication: str, key_takeaways: List[dict], implications: List[dict],
    background: List[dict], project_config, description: str = "",
) -> str:
    """
    Single entry point — dispatches to the correct renderer based on
    project_config.template_style ("ialert" | "gsk" | "jj").
    """
    s = project_config.template_style
    kwargs = dict(
        headline=headline, date=date, source_name=source_name,
        source_url=source_url, indication=indication,
        project_name=project_config.project_name,
        key_takeaways=key_takeaways, implications=implications,
        background=background,
        label_kt=project_config.label_key_takeaways,
        label_imp=project_config.label_implications,
        label_bg=project_config.label_background,
        primary_color=project_config.primary_color,
    )
    if s == "ialert":
        return _render_ialert(**kwargs, secondary_color=project_config.secondary_color)
    elif s == "gsk":
        return _render_gsk(
            **kwargs, description=description,
            greeting=project_config.greeting or "Dear team,",
            header_image_base64=project_config.header_image_base64,
            header_image_mime=project_config.header_image_mime,
        )
    elif s == "jj":
        return _render_jj(
            **kwargs,
            link_color=project_config.secondary_color,
            greeting=project_config.greeting or "Dear all,",
            disclaimer=project_config.disclaimer,
            implications_audience=project_config.implications_audience,
        )
    else:
        raise ValueError(f"Unknown template_style: '{s}'")


# ─── Session email builders (project-agnostic) ───────────────────────────────

def build_job_complete_html(session_name, session_id, article_count,
                             high_priority_count, duration_seconds,
                             sources_used, app_url, project_name="CI Monitor"):
    NAVY = "#004B8D"
    dur = f"{duration_seconds // 60}m {duration_seconds % 60}s" if duration_seconds else "—"
    srcs = ", ".join(sources_used) if sources_used else "All configured sources"
    return f"""<!DOCTYPE html><html><head><meta charset="UTF-8"></head>
<body style="margin:0;padding:0;background:#f4f6f9;font-family:Arial,Helvetica,sans-serif;">
<table width="580" cellpadding="0" cellspacing="0" style="margin:0 auto;background:white;border:1px solid #dde3ea;">
  <tr><td style="background:{NAVY};padding:14px 24px;">
    <table width="100%" cellpadding="0" cellspacing="0"><tr>
      <td style="color:white;font-size:16px;font-weight:bold;">CI Monitor</td>
      <td style="color:rgba(255,255,255,0.7);font-size:11px;text-align:right;">Session Complete</td>
    </tr></table>
  </td></tr>
  <tr><td style="padding:24px 24px 10px;">
    <div style="font-size:18px;font-weight:bold;color:#1a1a1a;">Scraping session complete</div>
    <div style="font-size:13px;color:#666;margin-top:4px;">{escape(session_name)} &nbsp;·&nbsp; {escape(project_name)}</div>
  </td></tr>
  <tr><td style="padding:10px 24px 20px;">
    <table width="100%" cellpadding="0" cellspacing="0" style="background:#E6F2FF;border-radius:6px;"><tr>
      <td style="padding:14px 20px;text-align:center;border-right:1px solid #c8dff5;">
        <div style="font-size:28px;font-weight:bold;color:{NAVY};">{article_count}</div>
        <div style="font-size:11px;color:#555;margin-top:2px;">Total Articles</div>
      </td>
      <td style="padding:14px 20px;text-align:center;border-right:1px solid #c8dff5;">
        <div style="font-size:28px;font-weight:bold;color:#CC0000;">{high_priority_count}</div>
        <div style="font-size:11px;color:#555;margin-top:2px;">High Priority</div>
      </td>
      <td style="padding:14px 20px;text-align:center;">
        <div style="font-size:18px;font-weight:bold;color:#28A745;">{dur}</div>
        <div style="font-size:11px;color:#555;margin-top:2px;">Duration</div>
      </td>
    </tr></table>
  </td></tr>
  <tr><td style="padding:0 24px 16px;font-size:12px;color:#666;"><b>Sources:</b> {escape(srcs)} &nbsp;·&nbsp; <b>Session ID:</b> {session_id}</td></tr>
  <tr><td style="padding:0 24px 24px;">
    <a href="{app_url}/articles" style="display:inline-block;background:{NAVY};color:white;font-size:13px;font-weight:bold;padding:10px 22px;border-radius:4px;text-decoration:none;">View Articles →</a>
  </td></tr>
  <tr><td style="background:#f4f6f9;padding:10px 24px;border-top:1px solid #dde3ea;font-size:10px;color:#999;text-align:center;">CI Monitor · Automated Competitive Intelligence</td></tr>
</table></body></html>"""


def build_summary_html(session_name, session_id, articles, app_url, project_name="CI Monitor"):
    NAVY, RED = "#004B8D", "#CC0000"
    high = [a for a in articles if a.get("priority") == "high"]
    rows = "".join(
        f"""<tr style="background:{'#f8f9fa' if i%2==1 else 'white'};">
          <td style="padding:8px 12px;border-left:3px solid {RED};">
            <div style="font-size:12px;font-weight:bold;color:#1a1a1a;">{escape(a.get('title',''))}</div>
            <div style="font-size:11px;color:#666;margin-top:2px;">
              {escape(a.get('indication',''))} · {escape(a.get('source',''))} · {escape(a.get('date',''))}
              &nbsp;·&nbsp; <a href="{a.get('source_url','#')}" style="color:{NAVY};">Source ↗</a>
            </div>
          </td></tr>"""
        for i, a in enumerate(high)
    )
    return f"""<!DOCTYPE html><html><head><meta charset="UTF-8"></head>
<body style="margin:0;padding:0;background:#f4f6f9;font-family:Arial,Helvetica,sans-serif;">
<table width="620" cellpadding="0" cellspacing="0" style="margin:0 auto;background:white;border:1px solid #dde3ea;">
  <tr><td style="background:{NAVY};padding:14px 20px;">
    <table width="100%" cellpadding="0" cellspacing="0"><tr>
      <td style="color:white;font-size:16px;font-weight:bold;">CI Monitor</td>
      <td style="color:rgba(255,255,255,0.7);font-size:11px;text-align:right;">Session Summary</td>
    </tr></table>
  </td></tr>
  <tr><td style="padding:16px 20px 8px;">
    <div style="font-size:15px;font-weight:bold;color:#1a1a1a;">{escape(session_name)} — {escape(project_name)}</div>
    <div style="font-size:12px;color:#666;margin-top:2px;">
      {len(articles)} articles &nbsp;·&nbsp; <span style="color:{RED};font-weight:bold;">{len(high)} high priority</span>
    </div>
  </td></tr>
  <tr><td style="padding:4px 20px 2px;font-size:11px;font-weight:bold;color:{RED};text-transform:uppercase;letter-spacing:0.5px;">High Priority Articles</td></tr>
  <tr><td style="padding:0 20px 12px;"><table width="100%" cellpadding="0" cellspacing="4">{rows}</table></td></tr>
  <tr><td style="padding:0 20px 20px;">
    <a href="{app_url}/articles?session={session_id}" style="display:inline-block;background:{NAVY};color:white;font-size:13px;font-weight:bold;padding:10px 22px;border-radius:4px;text-decoration:none;">Review All Articles →</a>
  </td></tr>
  <tr><td style="background:#f4f6f9;padding:10px 20px;border-top:1px solid #dde3ea;font-size:10px;color:#999;text-align:center;">CI Monitor · Session ID {session_id}</td></tr>
</table></body></html>"""


def build_article_alert_html(
    article_id, headline, date, source_name, source_url,
    indication, region, priority, companies, drugs, description,
    implications, approve_url, reject_url, prepare_url,
):
    NAVY, RED, GREEN = "#004B8D", "#CC0000", "#28A745"
    pc = RED if priority == "high" else "#FF9500"
    imp_html = _bullets_to_html(implications, font_size="12px")
    return f"""<!DOCTYPE html><html><head><meta charset="UTF-8"></head>
<body style="margin:0;padding:0;background:#f4f6f9;font-family:Arial,Helvetica,sans-serif;">
<table width="620" cellpadding="0" cellspacing="0" style="margin:0 auto;background:white;border:1px solid #dde3ea;">
  <tr><td style="background:{NAVY};padding:14px 20px;">
    <table width="100%" cellpadding="0" cellspacing="0"><tr>
      <td style="color:white;font-size:16px;font-weight:bold;">CI Monitor</td>
      <td style="color:rgba(255,255,255,0.7);font-size:11px;text-align:right;">Competitive Intelligence Alert</td>
    </tr></table>
  </td></tr>
  <tr><td style="padding:10px 20px;background:#E6F2FF;border-bottom:2px solid {NAVY};">
    <span style="background:{pc};color:white;font-size:10px;font-weight:bold;padding:3px 8px;border-radius:3px;">{priority.upper()} PRIORITY</span>
    <span style="background:{NAVY};color:white;font-size:10px;font-weight:bold;padding:3px 8px;border-radius:3px;margin-left:6px;">{escape(indication)}</span>
    <span style="color:#555;font-size:11px;margin-left:8px;">{escape(region)}</span>
    <span style="float:right;font-size:11px;color:#666;">{escape(date)}</span>
  </td></tr>
  <tr><td style="padding:16px 20px 10px;">
    <div style="font-size:16px;font-weight:bold;color:#1a1a1a;line-height:1.4;">{escape(headline)}</div>
    <div style="font-size:12px;color:#666;margin-top:5px;">Source: <a href="{source_url}" style="color:{NAVY};">{escape(source_name)}</a></div>
  </td></tr>
  <tr><td style="padding:4px 20px 10px;font-size:11px;color:#555;">
    <b>Companies:</b> {escape(", ".join(companies) or "—")} &nbsp;·&nbsp; <b>Assets:</b> {escape(", ".join(drugs) or "—")}
  </td></tr>
  <tr><td style="padding:0 20px;"><div style="border-top:1px solid #eee;"></div></td></tr>
  <tr><td style="padding:12px 20px 6px;">
    <div style="font-size:12px;font-weight:bold;color:{NAVY};text-transform:uppercase;letter-spacing:0.5px;margin-bottom:6px;">Summary</div>
    <div style="font-size:13px;color:#333;line-height:1.6;">{escape(description or headline)}</div>
  </td></tr>
  <tr><td style="padding:10px 20px 14px;">
    <div style="font-size:12px;font-weight:bold;color:{NAVY};text-transform:uppercase;letter-spacing:0.5px;margin-bottom:6px;">Strategic Implications</div>
    <div style="background:#f8f9fa;border-left:3px solid {RED};padding:10px 14px;">{imp_html}</div>
  </td></tr>
  <tr><td style="padding:0 20px;"><div style="border-top:1px solid #eee;"></div></td></tr>
  <tr><td style="padding:16px 20px 20px;">
    <div style="font-size:12px;color:#666;margin-bottom:10px;">Take action on this article:</div>
    <table cellpadding="0" cellspacing="0"><tr>
      <td style="padding-right:8px;"><a href="{approve_url}" style="display:inline-block;background:{GREEN};color:white;font-size:12px;font-weight:bold;padding:9px 18px;border-radius:4px;text-decoration:none;">&#10003; Approve</a></td>
      <td style="padding-right:8px;"><a href="{reject_url}" style="display:inline-block;background:#6c757d;color:white;font-size:12px;font-weight:bold;padding:9px 18px;border-radius:4px;text-decoration:none;">&#10007; Reject</a></td>
      <td><a href="{prepare_url}" style="display:inline-block;background:{RED};color:white;font-size:12px;font-weight:bold;padding:9px 18px;border-radius:4px;text-decoration:none;">Prepare Client Template &#8594;</a></td>
    </tr></table>
  </td></tr>
  <tr><td style="background:#f4f6f9;padding:10px 20px;border-top:1px solid #dde3ea;font-size:10px;color:#999;text-align:center;">
    CI Monitor &middot; Article ID: {article_id} &middot; Review before forwarding to clients.
  </td></tr>
</table></body></html>"""
