"""
Email Sequence Service
Place at: app/services/email_sequence_service.py

Orchestrates 3-part email sequence after a scraping session:
  1. Job Complete  → owner (session stats)
  2. Summary       → distribution list (all articles)
  3. Article Alerts → one per high-priority article (implications + action buttons)

Demo mode  (analyst1): returns dict of .eml bytes for zip download
Live mode  (analyst2): sends via Microsoft Graph API
"""

import asyncio
import os
from datetime import datetime, timezone
from typing import List, Optional, Dict
import logging

from app.services.implications_service import generate_implications
from app.services.template_service import (
    build_article_alert_html, build_job_complete_html, build_summary_html,
)
from app.services.eml_service import (
    article_alert_eml, job_complete_eml, summary_eml,
)
from app.config.projects import get_project_or_default

logger = logging.getLogger(__name__)

APP_URL = os.getenv("APP_BASE_URL", "http://localhost:5173")


async def _send_or_store(
    html: str,
    subject: str,
    from_email: str,
    to_email: str,
    eml_builder_fn,
    eml_kwargs: dict,
    use_graph: bool,
    graph_cc: Optional[List[str]] = None,
) -> Optional[bytes]:
    """
    Either send via Graph API (live) or return .eml bytes (demo).
    Returns bytes for demo, None for live (already sent).
    """
    if use_graph:
        from app.services.graph_email_service import send_email
        await send_email(
            subject=subject,
            html_body=html,
            to_addresses=[to_email],
            from_address=from_email,
            cc_addresses=graph_cc,
        )
        return None
    else:
        return eml_builder_fn(**eml_kwargs, html_body=html)


async def generate_session_email_sequence(
    session_id: int,
    session_name: str,
    articles: List[dict],
    from_email: str = "aman@iqvia.com",
    to_email: str = "aman@iqvia.com",
    dist_list_emails: Optional[List[str]] = None,
    project_slug: str = "autoantibody-cibi",
    app_base_url: str = APP_URL,
    started_at: Optional[datetime] = None,
    completed_at: Optional[datetime] = None,
    use_graph: bool = False,   # True for analyst2 live mode
) -> Dict[str, Optional[bytes]]:
    """
    Generate (and optionally send) all emails for a session.

    Returns dict:
      demo mode → {"job_complete": bytes, "summary": bytes, "article_1": bytes, ...}
      live mode → {"job_complete": None, "summary": None, ...}  (already sent via Graph)
    """
    project = get_project_or_default(project_slug)
    result: Dict[str, Optional[bytes]] = {}

    high_priority = [a for a in articles if a.get("priority") == "high"]
    duration_seconds = 0
    if started_at and completed_at:
        duration_seconds = int((completed_at - started_at).total_seconds())

    sources_used = list({a.get("source_category", "rss") for a in articles})

    # ── 1. Job Complete ───────────────────────────────────────────────────────
    try:
        jc_html = build_job_complete_html(
            session_name=session_name, session_id=session_id,
            article_count=len(articles), high_priority_count=len(high_priority),
            duration_seconds=duration_seconds, sources_used=sources_used,
            app_url=app_base_url, project_name=project.project_name,
        )
        subject_jc = (
            f"[CI Monitor] Session Complete — {session_name} | "
            f"{len(articles)} articles ({len(high_priority)} high)"
        )
        result["job_complete"] = await _send_or_store(
            html=jc_html, subject=subject_jc,
            from_email=from_email, to_email=to_email,
            eml_builder_fn=job_complete_eml,
            eml_kwargs=dict(
                from_addr=from_email, to_addr=to_email,
                session_name=session_name, article_count=len(articles),
                high_priority_count=len(high_priority),
            ),
            use_graph=use_graph,
        )
    except Exception as e:
        logger.error(f"Job complete email error: {e}")

    # ── 2. Summary ────────────────────────────────────────────────────────────
    try:
        sum_html = build_summary_html(
            session_name=session_name, session_id=session_id,
            articles=articles, app_url=app_base_url,
            project_name=project.project_name,
        )
        subject_sum = (
            f"[CI Monitor] Session Summary — {len(high_priority)} high priority | {session_name}"
        )
        result["summary"] = await _send_or_store(
            html=sum_html, subject=subject_sum,
            from_email=from_email, to_email=to_email,
            eml_builder_fn=summary_eml,
            eml_kwargs=dict(
                from_addr=from_email, to_addr=to_email,
                session_name=session_name, total_count=len(articles),
                high_count=len(high_priority),
                cc_addrs=dist_list_emails or None,
            ),
            use_graph=use_graph,
            graph_cc=dist_list_emails,
        )
    except Exception as e:
        logger.error(f"Summary email error: {e}")

    # ── 3. Individual article alerts (high priority only) ─────────────────────
    async def _build_article_email(article: dict) -> tuple:
        aid = article.get("id", 0)
        try:
            content = await generate_implications(
                title=article.get("title", ""),
                description=article.get("description", ""),
                source_name=article.get("source", ""),
                indication=article.get("indication", "General"),
                companies_mentioned=article.get("companies_mentioned", []),
                drug_names_mentioned=article.get("drug_names_mentioned", []),
                project_slug=project_slug,
                region=article.get("region", "Global"),
            )
            approve_url = f"{app_base_url}/articles?action=approve&id={aid}"
            reject_url = f"{app_base_url}/articles?action=reject&id={aid}"
            prepare_url = f"{app_base_url}/articles?action=prepare&id={aid}"

            html = build_article_alert_html(
                article_id=aid,
                headline=article.get("title", ""),
                date=article.get("date", ""),
                source_name=article.get("source", ""),
                source_url=article.get("source_url", "#"),
                indication=article.get("indication", ""),
                region=article.get("region", "Global"),
                priority=article.get("priority", "high"),
                companies=article.get("companies_mentioned", []),
                drugs=article.get("drug_names_mentioned", []),
                description=article.get("description", ""),
                implications=content.get("implications", []),
                approve_url=approve_url,
                reject_url=reject_url,
                prepare_url=prepare_url,
            )

            ind = article.get("indication", "")
            title = article.get("title", "")
            short = title[:90] + "..." if len(title) > 90 else title
            subject = f"[HIGH] {ind} | {short}"

            eml_bytes = await _send_or_store(
                html=html, subject=subject,
                from_email=from_email, to_email=to_email,
                eml_builder_fn=article_alert_eml,
                eml_kwargs=dict(
                    from_addr=from_email, to_addr=to_email,
                    indication=ind, headline=title, priority="high",
                ),
                use_graph=use_graph,
            )
            return f"article_{aid}", eml_bytes

        except Exception as e:
            logger.error(f"Article email error for {aid}: {e}")
            return f"article_{aid}", None

    if high_priority:
        tasks = [_build_article_email(a) for a in high_priority]
        for item in await asyncio.gather(*tasks, return_exceptions=True):
            if isinstance(item, tuple):
                result[item[0]] = item[1]

    logger.info(
        f"Session {session_id} ({project_slug}): "
        f"1 job_complete, 1 summary, {len(high_priority)} article alerts — "
        f"{'sent via Graph' if use_graph else 'generated as .eml'}"
    )
    return result
