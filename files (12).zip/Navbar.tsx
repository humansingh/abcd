import { BarChart3, UserCircle, FolderKanban } from 'lucide-react';
import { useNavigate, useLocation, Link } from 'react-router-dom';
import { useStore } from '@/store/useStore';

export function Navbar() {
  const user = useStore((s) => s.user);
  const logout = useStore((s) => s.logout);
  const navigate = useNavigate();
  const location = useLocation();

  const handleLogout = () => {
    logout();
    navigate('/login', { replace: true });
  };

  const navLink = (to: string, label: string) => (
    <Link
      to={to}
      className={`text-sm px-3 py-1 rounded transition-colors ${
        location.pathname === to
          ? 'text-white bg-white/10 font-medium'
          : 'text-nav-dark-foreground/70 hover:text-nav-dark-foreground'
      }`}
    >
      {label}
    </Link>
  );

  return (
    <header className="h-14 bg-nav-dark flex items-center justify-between px-4 shrink-0">
      {/* Logo — click to go home */}
      <button
        className="flex items-center gap-2 hover:opacity-80 transition-opacity"
        onClick={() => navigate('/dashboard')}
      >
        <BarChart3 className="h-5 w-5 text-nav-dark-foreground" />
        <span className="text-nav-dark-foreground font-bold text-lg">CI-Monitor</span>
      </button>

      {/* Centre nav links */}
      <nav className="flex items-center gap-1">
        {navLink('/projects', 'Projects')}
        {navLink('/articles', 'Articles')}
        {navLink('/schedules', 'Schedules')}
      </nav>

      {/* Right: user + logout */}
      <div className="flex items-center gap-3">
        <UserCircle className="h-5 w-5 text-nav-dark-foreground" />
        <span className="text-nav-dark-foreground text-sm">{user?.username}</span>
        <button
          onClick={handleLogout}
          className="text-nav-dark-foreground/70 text-sm hover:text-nav-dark-foreground transition-colors"
        >
          Logout
        </button>
      </div>
    </header>
  );
}

