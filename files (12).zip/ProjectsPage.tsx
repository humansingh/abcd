/**
 * ProjectsPage.tsx
 * Place at: src/pages/ProjectsPage.tsx
 *
 * Hub page showing all active projects with their latest session stats.
 * Click a project card → Articles page filtered to that project.
 * Harmonious with existing card/table UI — no new design patterns introduced.
 */

import { useNavigate } from 'react-router-dom';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ChevronRight, Clock, FileText, AlertCircle } from 'lucide-react';
import { PROJECTS, type ProjectConfig } from '@/constants/projects';
import { MOCK_SESSIONS, getLatestSession, getSessionsForProject } from '@/constants/mockSessions';
import { MOCK_ARTICLES } from '@/constants/mockArticles';

// ─── Helpers ──────────────────────────────────────────────────────────────────

function timeAgo(isoString: string): string {
  const diff = (Date.now() - new Date(isoString).getTime()) / 1000;
  if (diff < 3600) return `${Math.round(diff / 60)}m ago`;
  if (diff < 86400) return `${Math.round(diff / 3600)}h ago`;
  return `${Math.round(diff / 86400)}d ago`;
}

function formatTime(isoString: string): string {
  return new Date(isoString).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

function formatDate(isoString: string): string {
  return new Date(isoString).toLocaleDateString([], { day: 'numeric', month: 'short' });
}

// ─── Template style badge ─────────────────────────────────────────────────────
const STYLE_LABELS: Record<string, { label: string; bg: string; text: string }> = {
  ialert: { label: 'iAlert', bg: '#CC0000', text: 'white' },
  gsk:    { label: 'GSK',    bg: '#F26522', text: 'white' },
  jj:     { label: 'J&J',   bg: '#CC0000', text: 'white' },
};

// ─── Project card ─────────────────────────────────────────────────────────────
function ProjectCard({ project }: { project: ProjectConfig }) {
  const navigate = useNavigate();
  const session = getLatestSession(project.slug);
  const sessions = getSessionsForProject(project.slug);
  const allArticles = MOCK_ARTICLES.filter((a) => a.project_slug === project.slug);
  const styleInfo = STYLE_LABELS[project.templateStyle];

  const handleClick = () => {
    navigate(`/articles?project=${project.slug}`);
  };

  return (
    <Card
      className="rounded-lg overflow-hidden cursor-pointer hover:shadow-md transition-shadow border border-border group"
      onClick={handleClick}
    >
      {/* Coloured top accent bar */}
      <div className="h-1" style={{ background: project.primaryColor }} />

      <div className="p-5">
        {/* Header row */}
        <div className="flex items-start justify-between mb-3">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span
                className="text-xs font-bold px-2 py-0.5 rounded"
                style={{ background: styleInfo.bg, color: styleInfo.text }}
              >
                {styleInfo.label}
              </span>
              <span className="text-xs text-muted-foreground">{project.clientName}</span>
            </div>
            <h3 className="text-sm font-semibold text-foreground leading-snug">
              {project.projectName}
            </h3>
          </div>
          <ChevronRight className="h-4 w-4 text-muted-foreground group-hover:text-foreground transition-colors flex-shrink-0 mt-0.5" />
        </div>

        {/* Session stats */}
        {session ? (
          <div className="grid grid-cols-3 gap-2 mb-4">
            <div className="text-center p-2 bg-muted/40 rounded">
              <div className="text-lg font-bold text-foreground">{session.article_count}</div>
              <div className="text-[10px] text-muted-foreground leading-tight">Articles</div>
            </div>
            <div className="text-center p-2 bg-warning/10 rounded">
              <div className="text-lg font-bold text-warning">{session.high_priority_count}</div>
              <div className="text-[10px] text-muted-foreground leading-tight">High Priority</div>
            </div>
            <div className="text-center p-2 bg-muted/40 rounded">
              <div className="text-lg font-bold text-foreground">{sessions.length}</div>
              <div className="text-[10px] text-muted-foreground leading-tight">Sessions</div>
            </div>
          </div>
        ) : (
          <div className="h-14 flex items-center justify-center text-xs text-muted-foreground mb-4">
            No sessions yet
          </div>
        )}

        {/* Latest session row */}
        {session && (
          <div className="flex items-center gap-1.5 text-xs text-muted-foreground border-t border-border pt-3">
            <Clock className="h-3 w-3 flex-shrink-0" />
            <span>Last run {timeAgo(session.completed_at)}</span>
            <span className="mx-1">·</span>
            <span className="truncate">{session.session_name}</span>
          </div>
        )}
      </div>
    </Card>
  );
}

// ─── Session row in history table ─────────────────────────────────────────────
function SessionRow({
  sessionId,
  sessionName,
  projectSlug,
  completedAt,
  articleCount,
  highCount,
  status,
  onOpen,
}: {
  sessionId: number;
  sessionName: string;
  projectSlug: string;
  completedAt: string;
  articleCount: number;
  highCount: number;
  status: string;
  onOpen: () => void;
}) {
  const project = PROJECTS[projectSlug];
  const styleInfo = project ? STYLE_LABELS[project.templateStyle] : null;

  return (
    <tr className="border-b border-border hover:bg-muted/30 transition-colors">
      <td className="px-3 py-2.5">
        <div className="flex items-center gap-2">
          {styleInfo && (
            <span
              className="text-[10px] font-bold px-1.5 py-0.5 rounded flex-shrink-0"
              style={{ background: styleInfo.bg, color: styleInfo.text }}
            >
              {styleInfo.label}
            </span>
          )}
          <span className="text-sm font-medium">{sessionName}</span>
        </div>
      </td>
      <td className="px-3 py-2.5 text-xs text-muted-foreground">
        {formatDate(completedAt)} {formatTime(completedAt)}
      </td>
      <td className="px-3 py-2.5 text-xs">{articleCount}</td>
      <td className="px-3 py-2.5">
        <span className="text-xs font-semibold text-warning">{highCount}</span>
      </td>
      <td className="px-3 py-2.5">
        <div
          className={`inline-flex items-center gap-1 text-[10px] font-semibold px-1.5 py-0.5 rounded ${
            status === 'completed' ? 'bg-success/10 text-success' : 'bg-muted text-muted-foreground'
          }`}
        >
          {status === 'completed' ? '● Complete' : status}
        </div>
      </td>
      <td className="px-3 py-2.5">
        <Button
          size="sm"
          variant="outline"
          className="h-6 px-2 text-xs gap-1"
          onClick={(e) => { e.stopPropagation(); onOpen(); }}
        >
          <FileText className="h-3 w-3" /> Open
        </Button>
      </td>
    </tr>
  );
}

// ─── Main page ────────────────────────────────────────────────────────────────
export default function ProjectsPage() {
  const navigate = useNavigate();
  const projects = Object.values(PROJECTS);

  // All sessions sorted newest first
  const allSessions = [...MOCK_SESSIONS].sort(
    (a, b) => new Date(b.completed_at).getTime() - new Date(a.completed_at).getTime()
  );

  return (
    <div className="space-y-6">

      {/* Page header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-lg font-semibold text-foreground">Projects</h1>
          <p className="text-sm text-muted-foreground mt-0.5">
            {projects.length} active projects · {MOCK_SESSIONS.length} sessions
          </p>
        </div>
      </div>

      {/* Project cards */}
      <div className="grid grid-cols-3 gap-4">
        {projects.map((p) => (
          <ProjectCard key={p.slug} project={p} />
        ))}
      </div>

      {/* All sessions table */}
      <div>
        <h2 className="text-sm font-semibold text-foreground mb-3">All Scraping Sessions</h2>
        <Card className="rounded-lg overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border">
                <th className="table-header-cell">Session</th>
                <th className="table-header-cell w-[140px]">Completed</th>
                <th className="table-header-cell w-[80px]">Articles</th>
                <th className="table-header-cell w-[80px]">High Pri.</th>
                <th className="table-header-cell w-[100px]">Status</th>
                <th className="table-header-cell w-[80px]"></th>
              </tr>
            </thead>
            <tbody>
              {allSessions.map((s) => (
                <SessionRow
                  key={s.id}
                  sessionId={s.id}
                  sessionName={s.session_name}
                  projectSlug={s.project_slug}
                  completedAt={s.completed_at}
                  articleCount={s.article_count}
                  highCount={s.high_priority_count}
                  status={s.status}
                  onOpen={() => navigate(`/articles?project=${s.project_slug}&session=${s.id}`)}
                />
              ))}
            </tbody>
          </table>
        </Card>
      </div>

    </div>
  );
}
