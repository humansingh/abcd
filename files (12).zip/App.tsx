import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { AppLayout } from "@/components/layout/AppLayout";
import LoginPage from "@/pages/LoginPage";
import DashboardPage from "@/pages/DashboardPage";
import ProjectsPage from "@/pages/ProjectsPage";
import ScraperPage from "@/pages/ScraperPage";
import ArticlesPage from "@/pages/ArticlesPage";
import DeliveryPage from "@/pages/DeliveryPage";
import SchedulesPage from "@/pages/SchedulesPage";
import SummariesPage from "@/pages/SummariesPage";
import AnalyticsPage from "@/pages/AnalyticsPage";
import SettingsPage from "@/pages/SettingsPage";
import NotFound from "./pages/NotFound";
import { useStore } from "@/store/useStore";

const queryClient = new QueryClient();

// ─── Auth Guard ───────────────────────────────────────────────────────────────
function RequireAuth({ children }: { children: React.ReactNode }) {
  const isAuthenticated = useStore((s) => s.isAuthenticated);
  if (!isAuthenticated) return <Navigate to="/login" replace />;
  return <>{children}</>;
}

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          {/* Public */}
          <Route path="/login" element={<LoginPage />} />

          {/* Root redirect */}
          <Route
            path="/"
            element={
              <RequireAuth>
                <Navigate to="/dashboard" replace />
              </RequireAuth>
            }
          />

          {/* Protected routes */}
          <Route path="/dashboard"  element={<RequireAuth><AppLayout><DashboardPage /></AppLayout></RequireAuth>} />
          <Route path="/projects"   element={<RequireAuth><AppLayout><ProjectsPage /></AppLayout></RequireAuth>} />
          <Route path="/scraper"    element={<RequireAuth><AppLayout><ScraperPage /></AppLayout></RequireAuth>} />
          <Route path="/articles"   element={<RequireAuth><AppLayout><ArticlesPage /></AppLayout></RequireAuth>} />
          <Route path="/delivery"   element={<RequireAuth><AppLayout><DeliveryPage /></AppLayout></RequireAuth>} />
          <Route path="/schedules"  element={<RequireAuth><AppLayout><SchedulesPage /></AppLayout></RequireAuth>} />
          <Route path="/summaries"  element={<RequireAuth><AppLayout><SummariesPage /></AppLayout></RequireAuth>} />
          <Route path="/analytics"  element={<RequireAuth><AppLayout><AnalyticsPage /></AppLayout></RequireAuth>} />
          <Route path="/settings"   element={<RequireAuth><AppLayout><SettingsPage /></AppLayout></RequireAuth>} />

          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;

const queryClient = new QueryClient();

// ─── Auth Guard ───────────────────────────────────────────────────────────────
function RequireAuth({ children }: { children: React.ReactNode }) {
  const isAuthenticated = useStore((s) => s.isAuthenticated);
  if (!isAuthenticated) return <Navigate to="/login" replace />;
  return <>{children}</>;
}

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          {/* Public */}
          <Route path="/login" element={<LoginPage />} />

          {/* Root redirect */}
          <Route
            path="/"
            element={
              <RequireAuth>
                <Navigate to="/dashboard" replace />
              </RequireAuth>
            }
          />

          {/* Protected routes */}
          <Route path="/dashboard" element={<RequireAuth><AppLayout><DashboardPage /></AppLayout></RequireAuth>} />
          <Route path="/scraper"   element={<RequireAuth><AppLayout><ScraperPage /></AppLayout></RequireAuth>} />
          <Route path="/articles"  element={<RequireAuth><AppLayout><ArticlesPage /></AppLayout></RequireAuth>} />
          <Route path="/delivery"  element={<RequireAuth><AppLayout><DeliveryPage /></AppLayout></RequireAuth>} />
          <Route path="/schedules" element={<RequireAuth><AppLayout><SchedulesPage /></AppLayout></RequireAuth>} />
          <Route path="/summaries" element={<RequireAuth><AppLayout><SummariesPage /></AppLayout></RequireAuth>} />
          <Route path="/analytics" element={<RequireAuth><AppLayout><AnalyticsPage /></AppLayout></RequireAuth>} />
          <Route path="/settings"  element={<RequireAuth><AppLayout><SettingsPage /></AppLayout></RequireAuth>} />

          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
