/**
 * mockSessions.ts
 * Place at: src/constants/mockSessions.ts
 */

export interface MockSession {
  id: number;
  session_name: string;
  project_slug: string;
  started_at: string;
  completed_at: string;
  status: 'completed' | 'running' | 'failed';
  article_count: number;
  high_priority_count: number;
  sources_used: string[];
}

export const MOCK_SESSIONS: MockSession[] = [
  {
    id: 1,
    session_name: 'Immuno Competitors — Morning Run',
    project_slug: 'autoantibody-cibi',
    started_at: '2026-03-23T08:12:00Z',
    completed_at: '2026-03-23T08:14:34Z',
    status: 'completed',
    article_count: 20,
    high_priority_count: 9,
    sources_used: ['company_site', 'rss', 'clinical_trial', 'regulatory'],
  },
  {
    id: 2,
    session_name: 'Respiratory CI — Morning Run',
    project_slug: 'gsk-ci',
    started_at: '2026-03-23T06:05:00Z',
    completed_at: '2026-03-23T06:07:22Z',
    status: 'completed',
    article_count: 14,
    high_priority_count: 5,
    sources_used: ['company_site', 'rss', 'clinical_trial'],
  },
  {
    id: 3,
    session_name: 'IBD Competitive Landscape — Daily',
    project_slug: 'jj-ci',
    started_at: '2026-03-22T09:00:00Z',
    completed_at: '2026-03-22T09:02:48Z',
    status: 'completed',
    article_count: 11,
    high_priority_count: 4,
    sources_used: ['company_site', 'rss', 'regulatory'],
  },
];

/** Helper: get sessions for a project */
export function getSessionsForProject(projectSlug: string): MockSession[] {
  return MOCK_SESSIONS.filter((s) => s.project_slug === projectSlug);
}

/** Helper: get most recent session for a project */
export function getLatestSession(projectSlug: string): MockSession | undefined {
  return getSessionsForProject(projectSlug)[0];
}
