/**
 * ArticlesPage.tsx
 * Place at: src/pages/ArticlesPage.tsx
 *
 * Full rebuild:
 * - Table with session/indication/priority/status filters + search
 * - High-priority articles have orange left border
 * - Click any row → detail panel slides in from right (45% width)
 * - "Prepare Alert" per article → opens AlertPreviewPanel (AI + template + .eml)
 * - Approve/Reject from panel → updates article status badge
 * - URL param handling: ?action=approve&id=X, ?action=prepare&id=X
 *   (from email action links)
 * - "Send Email Alerts" button → generates .eml sequence for demo
 */

import { useState, useMemo, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  Download, ExternalLink, Mail, Loader2, ChevronRight,
  CheckCircle, XCircle, FileText,
} from 'lucide-react';
import { MOCK_ARTICLES, MockArticle, ApprovalStatus } from '@/constants/mockArticles';
import { MOCK_SESSIONS } from '@/constants/mockSessions';
import { INDICATIONS } from '@/constants/indications';
import { PROJECT_OPTIONS, getProject } from '@/constants/projects';
import { useStore } from '@/store/useStore';
import { apiFetch } from '@/lib/api';
import AlertPreviewPanel from '@/components/alerts/AlertPreviewPanel';

// ─── Types ────────────────────────────────────────────────────────────────────
type ArticleWithStatus = MockArticle & { approval_status: ApprovalStatus };

// ─── Priority badge ───────────────────────────────────────────────────────────
function PriorityBadge({ priority }: { priority: string }) {
  if (priority === 'high') return <span className="inline-block w-2 h-2 rounded-full bg-warning flex-shrink-0 mt-1" title="High priority" />;
  if (priority === 'low') return <span className="inline-block w-2 h-2 rounded-full bg-muted-foreground/40 flex-shrink-0 mt-1" title="Low priority" />;
  return null;
}

// ─── Status badge ─────────────────────────────────────────────────────────────
function StatusBadge({ status }: { status: ApprovalStatus }) {
  if (status === 'approved') return (
    <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-success">
      <CheckCircle className="h-3 w-3" />
    </span>
  );
  if (status === 'rejected') return (
    <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-muted-foreground">
      <XCircle className="h-3 w-3" />
    </span>
  );
  return null;
}

// ─── Source category label ─────────────────────────────────────────────────────
const SOURCE_CAT_LABELS: Record<string, string> = {
  rss: 'RSS',
  company_site: 'Company PR',
  clinical_trial: 'CT Registry',
  regulatory: 'Regulatory',
};

// ─── Main page ────────────────────────────────────────────────────────────────
export default function ArticlesPage() {
  const { isDemo } = useStore();
  const [searchParams, setSearchParams] = useSearchParams();

  // ── Project selection (from URL or default) ────────────────────────────────
  const [activeProjectSlug, setActiveProjectSlug] = useState(
    searchParams.get('project') || 'autoantibody-cibi'
  );
  const activeProject = getProject(activeProjectSlug);

  // ── Filters ────────────────────────────────────────────────────────────────
  const defaultSession = MOCK_SESSIONS.find((s) => s.project_slug === activeProjectSlug);
  const [sessionId, setSessionId] = useState(
    searchParams.get('session') || String(defaultSession?.id || '1')
  );
  const [search, setSearch] = useState('');
  const [indicationFilter, setIndicationFilter] = useState('all');
  const [priorityFilter, setPriorityFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [page, setPage] = useState(1);
  const perPage = 25;

  // ── Article state (including approval status) ──────────────────────────────
  const [articleStatuses, setArticleStatuses] = useState<Record<number, ApprovalStatus>>({});

  // ── Panel state ────────────────────────────────────────────────────────────
  const [selectedArticle, setSelectedArticle] = useState<MockArticle | null>(null);
  const [panelMode, setPanelMode] = useState<'detail' | 'alert'>('detail');

  // ── Email sequence state ───────────────────────────────────────────────────
  const [sendingEmails, setSendingEmails] = useState(false);
  const [emailsSent, setEmailsSent] = useState(false);

  // ── Handle URL params (from email action links) ────────────────────────────
  useEffect(() => {
    const action = searchParams.get('action');
    const id = searchParams.get('id');
    if (!action || !id) return;

    const articleId = Number(id);
    const article = MOCK_ARTICLES.find((a) => a.id === articleId);
    if (!article) return;

    if (action === 'approve') {
      setArticleStatuses((prev) => ({ ...prev, [articleId]: 'approved' }));
    } else if (action === 'reject') {
      setArticleStatuses((prev) => ({ ...prev, [articleId]: 'rejected' }));
    } else if (action === 'prepare') {
      setSelectedArticle(article);
      setPanelMode('alert');
    }
  }, [searchParams]);

  const projectSessions = MOCK_SESSIONS.filter((s) => s.project_slug === activeProjectSlug);

  // Switch project: reset session to that project's first session
  const handleProjectSwitch = (slug: string) => {
    setActiveProjectSlug(slug);
    const firstSession = MOCK_SESSIONS.find((s) => s.project_slug === slug);
    if (firstSession) setSessionId(String(firstSession.id));
    setPage(1);
  };

  // ── Filtered + paginated articles ──────────────────────────────────────────
  const filtered = useMemo(() => {
    return MOCK_ARTICLES.filter((a) => {
      if (a.project_slug !== activeProjectSlug) return false;
      if (a.session_id !== Number(sessionId)) return false;
      if (indicationFilter !== 'all' && a.indication !== indicationFilter) return false;
      if (priorityFilter !== 'all' && a.priority !== priorityFilter) return false;
      const status = articleStatuses[a.id] || a.approval_status;
      if (statusFilter === 'pending' && status !== 'pending') return false;
      if (statusFilter === 'approved' && status !== 'approved') return false;
      if (statusFilter === 'rejected' && status !== 'rejected') return false;
      if (search && !a.title.toLowerCase().includes(search.toLowerCase()) &&
          !a.source.toLowerCase().includes(search.toLowerCase())) return false;
      return true;
    });
  }, [sessionId, indicationFilter, priorityFilter, statusFilter, search, articleStatuses]);

  const totalPages = Math.ceil(filtered.length / perPage);
  const paginated = filtered.slice((page - 1) * perPage, page * perPage);

  const highCount = filtered.filter((a) => a.priority === 'high').length;
  const pendingCount = filtered.filter((a) => (articleStatuses[a.id] || a.approval_status) === 'pending').length;

  // ── Actions ────────────────────────────────────────────────────────────────
  const handleSelectArticle = (article: MockArticle, mode: 'detail' | 'alert' = 'detail') => {
    setSelectedArticle(article);
    setPanelMode(mode);
  };

  const handleApprove = (id: number) => {
    setArticleStatuses((prev) => ({ ...prev, [id]: 'approved' }));
  };

  const handleReject = (id: number) => {
    setArticleStatuses((prev) => ({ ...prev, [id]: 'rejected' }));
  };

  // ── Email sequence download ────────────────────────────────────────────────
  const handleSendEmails = async () => {
    setSendingEmails(true);
    if (isDemo) {
      // Demo: import and run the demo email sequence builder
      const { buildDemoEmailSequence } = await import('@/lib/demoEmailSequence');
      await buildDemoEmailSequence(
        MOCK_ARTICLES.filter((a) => a.session_id === Number(sessionId)),
        sessionId
      );
      setEmailsSent(true);
      setTimeout(() => setEmailsSent(false), 4000);
    } else {
      try {
        const res = await fetch(`/api/alerts/session/${sessionId}/emails`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${localStorage.getItem('ci_token') || ''}`,
          },
          body: JSON.stringify({
            session_id: Number(sessionId),
            to_email: 'aman@iqvia.com',
            from_email: 'aman@iqvia.com',
            project_slug: 'autoantibody-cibi',
            app_base_url: window.location.origin,
          }),
        });
        const blob = await res.blob();
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `CI_Monitor_Session_${sessionId}_Emails.zip`;
        a.click();
        URL.revokeObjectURL(url);
        setEmailsSent(true);
        setTimeout(() => setEmailsSent(false), 4000);
      } catch {
        // swallow
      }
    }
    setSendingEmails(false);
  };

  const panelOpen = !!selectedArticle;

  return (
    <div className="flex gap-0 h-full" style={{ minHeight: 0 }}>

      {/* ── LEFT: Table area ───────────────────────────────────────────────── */}
      <div className={`flex flex-col gap-4 transition-all duration-200 ${panelOpen ? 'w-[55%]' : 'w-full'}`}>

        {/* Filters bar */}
        <div className="flex items-center gap-2 flex-wrap">
          {/* Project switcher */}
          <div className="flex rounded-md border border-border overflow-hidden">
            {PROJECT_OPTIONS.map((p) => (
              <button
                key={p.value}
                onClick={() => handleProjectSwitch(p.value)}
                className={`px-3 py-1 text-xs font-medium transition-colors whitespace-nowrap ${
                  activeProjectSlug === p.value
                    ? 'bg-primary text-primary-foreground'
                    : 'bg-background text-muted-foreground hover:bg-muted'
                }`}
              >
                {p.label}
              </button>
            ))}
          </div>

          <Select value={sessionId} onValueChange={(v) => { setSessionId(v); setPage(1); }}>
            <SelectTrigger className="w-[200px] rounded-md">
              <SelectValue placeholder="Select session" />
            </SelectTrigger>
            <SelectContent>
              {projectSessions.map((s) => (
                <SelectItem key={s.id} value={String(s.id)}>{s.session_name}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Input
            placeholder="Search title / source…"
            value={search}
            onChange={(e) => { setSearch(e.target.value); setPage(1); }}
            className="w-[180px] rounded-md"
          />

          <Select value={indicationFilter} onValueChange={(v) => { setIndicationFilter(v); setPage(1); }}>
            <SelectTrigger className="w-[150px] rounded-md">
              <SelectValue placeholder="Indication" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Indications</SelectItem>
              {INDICATIONS.map((i) => (
                <SelectItem key={i.value} value={i.value}>{i.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          {/* Priority filter buttons */}
          <div className="flex rounded-md border border-border overflow-hidden">
            {(['all', 'high', 'normal', 'low'] as const).map((p) => (
              <button
                key={p}
                onClick={() => { setPriorityFilter(p); setPage(1); }}
                className={`px-2.5 py-1 text-xs font-medium transition-colors ${
                  priorityFilter === p
                    ? 'bg-primary text-primary-foreground'
                    : 'bg-background text-muted-foreground hover:bg-muted'
                }`}
              >
                {p === 'all' ? 'All' : p.charAt(0).toUpperCase() + p.slice(1)}
              </button>
            ))}
          </div>

          {/* Status filter */}
          <Select value={statusFilter} onValueChange={(v) => { setStatusFilter(v); setPage(1); }}>
            <SelectTrigger className="w-[130px] rounded-md">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="approved">Approved</SelectItem>
              <SelectItem value="rejected">Rejected</SelectItem>
            </SelectContent>
          </Select>

          <div className="ml-auto flex items-center gap-2">
            {/* Email sequence button */}
            <Button
              variant="outline"
              size="sm"
              className="gap-1.5 text-xs"
              onClick={handleSendEmails}
              disabled={sendingEmails}
            >
              {sendingEmails
                ? <Loader2 className="h-3.5 w-3.5 animate-spin" />
                : emailsSent
                ? <CheckCircle className="h-3.5 w-3.5 text-success" />
                : <Mail className="h-3.5 w-3.5" />
              }
              {emailsSent ? 'Downloaded!' : 'Send Email Alerts'}
            </Button>

            <Button variant="outline" size="sm" className="gap-1.5 text-xs">
              <Download className="h-3.5 w-3.5" /> Export
            </Button>
          </div>
        </div>

        {/* Stats strip */}
        <div className="flex items-center gap-3 text-xs text-muted-foreground">
          <span><span className="font-semibold text-foreground">{filtered.length}</span> articles</span>
          <span>·</span>
          <span><span className="font-semibold text-warning">{highCount}</span> high priority</span>
          <span>·</span>
          <span><span className="font-semibold text-foreground">{pendingCount}</span> pending review</span>
        </div>

        {/* Table */}
        <Card className="rounded-lg overflow-hidden flex-1">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr>
                  <th className="table-header-cell w-[8px]"></th>
                  <th className="table-header-cell w-[70px]">Week</th>
                  <th className="table-header-cell w-[90px]">Date</th>
                  <th className="table-header-cell w-[70px]">Indication</th>
                  <th className="table-header-cell">Title</th>
                  <th className="table-header-cell w-[120px]">Source</th>
                  <th className="table-header-cell w-[70px]">Type</th>
                  <th className="table-header-cell w-[50px]">Status</th>
                  <th className="table-header-cell w-[80px]">Actions</th>
                </tr>
              </thead>
              <tbody>
                {paginated.map((article, i) => {
                  const status = articleStatuses[article.id] || article.approval_status;
                  const isSelected = selectedArticle?.id === article.id;
                  return (
                    <tr
                      key={article.id}
                      className={`cursor-pointer transition-colors ${
                        isSelected
                          ? 'bg-primary/5 border-l-[3px] border-l-primary'
                          : article.priority === 'high'
                          ? 'border-l-[3px] border-l-warning hover:bg-muted/50'
                          : `${i % 2 === 1 ? 'bg-table-stripe' : ''} border-l-[3px] border-l-transparent hover:bg-muted/50`
                      } ${status === 'rejected' ? 'opacity-50' : ''}`}
                      onClick={() => handleSelectArticle(article)}
                    >
                      <td className="px-0 py-2">
                        <PriorityBadge priority={article.priority} />
                      </td>
                      <td className="px-2 py-2 text-xs text-muted-foreground">{article.week_of}</td>
                      <td className="px-2 py-2 text-xs">{article.date}</td>
                      <td className="px-2 py-2">
                        <span className="inline-block text-xs font-semibold bg-primary/10 text-primary px-1.5 py-0.5 rounded">
                          {article.indication}
                        </span>
                      </td>
                      <td className="px-2 py-2">
                        <div className="text-sm leading-snug line-clamp-2">{article.title}</div>
                        {article.companies_mentioned.length > 0 && (
                          <div className="text-xs text-muted-foreground mt-0.5">
                            {article.companies_mentioned.slice(0, 2).join(' · ')}
                          </div>
                        )}
                      </td>
                      <td className="px-2 py-2 text-xs text-muted-foreground">
                        <div className="line-clamp-1">{article.source}</div>
                      </td>
                      <td className="px-2 py-2">
                        <span className="text-xs text-muted-foreground">
                          {SOURCE_CAT_LABELS[article.source_category] || article.source_category}
                        </span>
                      </td>
                      <td className="px-2 py-2">
                        <StatusBadge status={status} />
                      </td>
                      <td className="px-2 py-2">
                        <div className="flex items-center gap-0.5">
                          {article.priority === 'high' && status === 'pending' && (
                            <button
                              title="Prepare Client Alert"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleSelectArticle(article, 'alert');
                              }}
                              className="p-1 rounded hover:bg-primary/10 text-primary"
                            >
                              <FileText className="h-3.5 w-3.5" />
                            </button>
                          )}
                          <a
                            href={article.source_url}
                            target="_blank"
                            rel="noopener noreferrer"
                            onClick={(e) => e.stopPropagation()}
                            className="p-1 rounded hover:bg-muted text-muted-foreground"
                          >
                            <ExternalLink className="h-3.5 w-3.5" />
                          </a>
                          {panelOpen && (
                            <ChevronRight className={`h-3.5 w-3.5 text-muted-foreground transition-transform ${isSelected ? 'rotate-90' : ''}`} />
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}

                {paginated.length === 0 && (
                  <tr>
                    <td colSpan={9} className="px-4 py-8 text-center text-sm text-muted-foreground">
                      No articles match the current filters.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="flex items-center justify-between px-4 py-2 border-t border-border">
              <span className="text-xs text-muted-foreground">{filtered.length} articles</span>
              <div className="flex gap-1">
                {Array.from({ length: Math.min(totalPages, 8) }, (_, i) => (
                  <Button
                    key={i}
                    size="sm"
                    variant={page === i + 1 ? 'default' : 'outline'}
                    className="h-7 w-7 p-0 text-xs"
                    onClick={() => setPage(i + 1)}
                  >
                    {i + 1}
                  </Button>
                ))}
              </div>
            </div>
          )}
        </Card>
      </div>

      {/* ── RIGHT: Detail / Alert panel ────────────────────────────────────── */}
      {panelOpen && selectedArticle && (
        <div className="w-[45%] flex-shrink-0 border-l border-border h-full overflow-hidden">

          {/* Panel mode tabs */}
          <div className="flex border-b border-border bg-muted/20">
            <button
              className={`flex-1 px-4 py-2 text-xs font-medium transition-colors ${
                panelMode === 'detail'
                  ? 'border-b-2 border-primary text-primary'
                  : 'text-muted-foreground hover:text-foreground'
              }`}
              onClick={() => setPanelMode('detail')}
            >
              Article Detail
            </button>
            <button
              className={`flex-1 px-4 py-2 text-xs font-medium transition-colors ${
                panelMode === 'alert'
                  ? 'border-b-2 border-primary text-primary'
                  : 'text-muted-foreground hover:text-foreground'
              }`}
              onClick={() => setPanelMode('alert')}
            >
              ✦ Client Alert
            </button>
          </div>

          {panelMode === 'detail' ? (
            /* ── Article detail view ─────────────────────────────────── */
            <div className="h-full overflow-y-auto p-4 space-y-4">
              <div>
                <div className="flex items-start gap-2 flex-wrap mb-2">
                  <Badge variant={selectedArticle.priority === 'high' ? 'destructive' : 'secondary'}>
                    {selectedArticle.priority.toUpperCase()}
                  </Badge>
                  <Badge variant="outline">{selectedArticle.indication}</Badge>
                  <Badge variant="outline">{selectedArticle.region}</Badge>
                </div>
                <h3 className="text-sm font-semibold leading-snug">{selectedArticle.title}</h3>
                <div className="text-xs text-muted-foreground mt-1">
                  {selectedArticle.source} · {selectedArticle.date}
                </div>
              </div>

              {selectedArticle.description && (
                <div>
                  <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-1">Summary</div>
                  <p className="text-sm leading-relaxed">{selectedArticle.description}</p>
                </div>
              )}

              {selectedArticle.companies_mentioned.length > 0 && (
                <div>
                  <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-1">Companies</div>
                  <div className="flex flex-wrap gap-1">
                    {selectedArticle.companies_mentioned.map((c) => (
                      <span key={c} className="text-xs bg-muted px-2 py-0.5 rounded">{c}</span>
                    ))}
                  </div>
                </div>
              )}

              {selectedArticle.drug_names_mentioned.length > 0 && (
                <div>
                  <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-1">Assets</div>
                  <div className="flex flex-wrap gap-1">
                    {selectedArticle.drug_names_mentioned.map((d) => (
                      <span key={d} className="text-xs bg-primary/10 text-primary px-2 py-0.5 rounded">{d}</span>
                    ))}
                  </div>
                </div>
              )}

              <div className="pt-2 space-y-2">
                <Button
                  className="w-full gap-2"
                  onClick={() => setPanelMode('alert')}
                  disabled={selectedArticle.priority !== 'high'}
                >
                  <FileText className="h-4 w-4" />
                  Prepare Client Alert
                </Button>
                {selectedArticle.priority !== 'high' && (
                  <p className="text-xs text-muted-foreground text-center">
                    Client alerts are generated for high-priority articles only.
                  </p>
                )}
                <a
                  href={selectedArticle.source_url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block"
                >
                  <Button variant="outline" className="w-full gap-2">
                    <ExternalLink className="h-4 w-4" /> Open Source
                  </Button>
                </a>
              </div>
            </div>
          ) : (
            /* ── Alert preview panel ─────────────────────────────────── */
            <div className="h-full overflow-hidden" style={{ height: 'calc(100vh - 140px)' }}>
              <AlertPreviewPanel
                article={selectedArticle}
                projectSlug={activeProjectSlug}
                onClose={() => setSelectedArticle(null)}
                onApprove={handleApprove}
                onReject={handleReject}
              />
            </div>
          )}
        </div>
      )}
    </div>
  );
}
