/**
 * AlertPreviewPanel.tsx
 * Place at: src/components/alerts/AlertPreviewPanel.tsx
 *
 * Shows the full iAlert client template preview with:
 * - AI generation via GPT-4.1
 * - Inline editable sections (Key Takeaways, Implications, Background)
 * - Download for Outlook (.eml)
 * - Approve / Reject article
 */

import { useState, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import {
  Loader2, Download, CheckCircle, XCircle, Pencil, Check, X,
  RefreshCw, ExternalLink, ChevronDown, ChevronUp,
} from 'lucide-react';
import { useStore } from '@/store/useStore';
import { apiFetch } from '@/lib/api';
import type { MockArticle } from '@/constants/mockArticles';
import { getProject } from '@/constants/projects';

// ─── Types ────────────────────────────────────────────────────────────────────
interface BulletPoint {
  text: string;
  sub_bullets: string[];
}

interface AlertContent {
  news_class: string;
  key_takeaways: BulletPoint[];
  implications: BulletPoint[];
  background: BulletPoint[];
}

// ─── Mock implications for demo (instant, no API call) ───────────────────────
function buildMockContent(article: MockArticle): AlertContent {
  const company = article.companies_mentioned[0] || 'the company';
  const drug = article.drug_names_mentioned[0] || 'the asset';

  return {
    news_class: article.indication === 'Biosimilar' ? 'biosimilar_approval_launch'
      : article.source_category === 'clinical_trial' ? 'clinical_trial_initiation'
      : article.title.toLowerCase().includes('approv') || article.title.toLowerCase().includes('grants') ? 'regulatory_approval'
      : article.title.toLowerCase().includes('phase 3') || article.title.toLowerCase().includes('phase 2') ? 'clinical_data_readout'
      : 'other',
    key_takeaways: [
      {
        text: `${company} has reported a significant development for ${drug} in ${article.indication} with implications for competitive positioning in this indication.`,
        sub_bullets: [
          `Source: ${article.source} — ${article.date}`,
          'Geographic scope: ' + article.region,
        ],
      },
      {
        text: article.description || article.title,
        sub_bullets: [],
      },
    ],
    implications: [
      {
        text: `This development ${article.priority === 'high' ? 'materially advances' : 'maintains'} ${company}'s competitive position in ${article.indication} and signals continued pipeline prioritisation for ${drug}.`,
        sub_bullets: [
          `Competitor activity in this mechanism of action and indication remains active — timeline to market relative to peers is a key differentiating factor`,
        ],
      },
      {
        text: `The competitive landscape in ${article.indication} is intensifying, with several assets at comparable or more advanced stages of development across IL-17, IL-23, and JAK inhibitor classes.`,
        sub_bullets: [
          'Cross-trial efficacy comparisons should be interpreted with caution given differences in patient populations and primary endpoints',
          'Label breadth, dosing convenience, and payer access will be critical commercial differentiators',
        ],
      },
      {
        text: `Key milestones to monitor include: regulatory submission timing, reimbursement decision outcomes, and competitive readout calendar — none of which have been fully disclosed at this stage.`,
        sub_bullets: [],
      },
    ],
    background: [
      {
        text: `${company} has established commercial and clinical presence across multiple autoimmune indications, with ${drug} forming a key part of the immunology portfolio.`,
        sub_bullets: [],
      },
      {
        text: `The ${article.indication} space has seen significant development activity over the past 24 months, with approved therapies across biologic and small molecule classes establishing a competitive benchmark for efficacy and safety.`,
        sub_bullets: [],
      },
    ],
  };
}

// ─── Editable bullets section ─────────────────────────────────────────────────
function BulletEditor({
  bullets,
  onChange,
  label,
  color,
}: {
  bullets: BulletPoint[];
  onChange: (b: BulletPoint[]) => void;
  label: string;
  color: string;
}) {
  const [editing, setEditing] = useState(false);
  const [raw, setRaw] = useState('');

  const startEdit = () => {
    // Flatten bullets to editable text format
    const text = bullets.map((b) => {
      let s = `• ${b.text}`;
      if (b.sub_bullets?.length) {
        s += '\n' + b.sub_bullets.map((sb) => `  ◦ ${sb}`).join('\n');
      }
      return s;
    }).join('\n');
    setRaw(text);
    setEditing(true);
  };

  const saveEdit = () => {
    // Parse the text back to bullets
    const lines = raw.split('\n');
    const result: BulletPoint[] = [];
    let current: BulletPoint | null = null;

    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed) continue;
      if (trimmed.startsWith('•')) {
        if (current) result.push(current);
        current = { text: trimmed.replace(/^•\s*/, ''), sub_bullets: [] };
      } else if (trimmed.startsWith('◦') && current) {
        current.sub_bullets.push(trimmed.replace(/^◦\s*/, ''));
      } else if (trimmed.startsWith('-') && current) {
        current.sub_bullets.push(trimmed.replace(/^-\s*/, ''));
      } else if (current) {
        // continuation of previous bullet
        current.text += ' ' + trimmed;
      } else {
        current = { text: trimmed, sub_bullets: [] };
      }
    }
    if (current) result.push(current);
    onChange(result);
    setEditing(false);
  };

  return (
    <div className="mb-0">
      {/* Section header */}
      <div
        className="flex items-center justify-between px-4 py-2"
        style={{ background: color }}
      >
        <span className="text-white font-bold text-sm">{label}</span>
        {!editing ? (
          <button
            onClick={startEdit}
            className="text-white/80 hover:text-white transition-colors"
            title="Edit this section"
          >
            <Pencil className="h-3.5 w-3.5" />
          </button>
        ) : (
          <div className="flex gap-1">
            <button onClick={saveEdit} className="text-white/80 hover:text-white" title="Save">
              <Check className="h-3.5 w-3.5" />
            </button>
            <button onClick={() => setEditing(false)} className="text-white/80 hover:text-white" title="Cancel">
              <X className="h-3.5 w-3.5" />
            </button>
          </div>
        )}
      </div>

      {/* Section content */}
      <div className="bg-white px-4 py-3">
        {editing ? (
          <div>
            <p className="text-xs text-muted-foreground mb-1.5">
              Use • for main bullets, ◦ for sub-bullets. One bullet per line.
            </p>
            <Textarea
              value={raw}
              onChange={(e) => setRaw(e.target.value)}
              className="text-xs font-mono min-h-[120px] rounded"
              autoFocus
            />
          </div>
        ) : (
          <ul className="list-none space-y-1.5 m-0 p-0">
            {bullets.map((b, i) => (
              <li key={i} className="text-sm leading-snug">
                <span className="mr-1.5">•</span>
                <span>{b.text}</span>
                {b.sub_bullets?.length > 0 && (
                  <ul className="ml-4 mt-1 space-y-0.5">
                    {b.sub_bullets.map((sb, j) => (
                      <li key={j} className="text-xs text-foreground/80 leading-snug">
                        <span className="mr-1">◦</span>{sb}
                      </li>
                    ))}
                  </ul>
                )}
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}

// ─── News class badge ─────────────────────────────────────────────────────────
const NEWS_CLASS_LABELS: Record<string, string> = {
  clinical_trial_initiation: 'Trial Initiation',
  clinical_data_readout: 'Data Readout',
  regulatory_approval: 'Regulatory Approval',
  regulatory_policy: 'Regulatory Policy',
  hta_reimbursement: 'HTA / Reimbursement',
  ma_licensing_partnership: 'M&A / Licensing',
  biosimilar_approval_launch: 'Biosimilar',
  other: 'Other',
};

// ─── Main Panel ───────────────────────────────────────────────────────────────
interface AlertPreviewPanelProps {
  article: MockArticle;
  projectSlug?: string;
  onClose: () => void;
  onApprove: (id: number) => void;
  onReject: (id: number) => void;
}

export default function AlertPreviewPanel({
  article,
  projectSlug = 'autoantibody-cibi',
  onClose,
  onApprove,
  onReject,
}: AlertPreviewPanelProps) {
  const { isDemo } = useStore();

  const [generating, setGenerating] = useState(false);
  const [content, setContent] = useState<AlertContent | null>(null);
  const [generationSource, setGenerationSource] = useState<string>('');
  const [downloading, setDownloading] = useState(false);
  const [actionDone, setActionDone] = useState<'approved' | 'rejected' | null>(null);
  const [showBackground, setShowBackground] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Update individual sections
  const setKeyTakeaways = useCallback(
    (bullets: BulletPoint[]) => setContent((c) => c ? { ...c, key_takeaways: bullets } : c),
    []
  );
  const setImplications = useCallback(
    (bullets: BulletPoint[]) => setContent((c) => c ? { ...c, implications: bullets } : c),
    []
  );
  const setBackground = useCallback(
    (bullets: BulletPoint[]) => setContent((c) => c ? { ...c, background: bullets } : c),
    []
  );

  // ── Generate ────────────────────────────────────────────────────────────────
  const handleGenerate = async () => {
    setGenerating(true);
    setError(null);

    if (isDemo) {
      // Demo: short delay then return mock content
      await new Promise((r) => setTimeout(r, 1800));
      setContent(buildMockContent(article));
      setGenerationSource('gpt-4.1 (demo)');
      setGenerating(false);
      return;
    }

    try {
      const res = await apiFetch<{
        content: AlertContent;
        generation_source: string;
      }>('/alerts/generate', {
        method: 'POST',
        body: JSON.stringify({
          article_id: article.id,
          project_slug: projectSlug,
        }),
      });
      setContent(res.content);
      setGenerationSource(res.generation_source);
    } catch (e) {
      setError('Generation failed. Using demo content.');
      setContent(buildMockContent(article));
      setGenerationSource('fallback');
    }
    setGenerating(false);
  };

  // ── Download .eml ────────────────────────────────────────────────────────────
  const handleDownloadEml = async () => {
    if (!content) return;
    setDownloading(true);

    try {
      if (isDemo) {
        const { buildDemoEml } = await import('@/lib/demoEml');
        buildDemoEml(article, content, projectSlug);
      } else {
        const res = await fetch(`/api/alerts/${article.id}/client-template-eml`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${localStorage.getItem('ci_token') || ''}`,
          },
          body: JSON.stringify({
            article_id: article.id,
            project_slug: projectSlug,
            content,
            to_email: 'aman@iqvia.com',
            from_email: 'aman@iqvia.com',
          }),
        });

        if (!res.ok) throw new Error('Download failed');

        const blob = await res.blob();
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `CI_Alert_${article.indication}_${article.id}.eml`;
        a.click();
        URL.revokeObjectURL(url);
      }
    } catch (e) {
      setError('Download failed. Please try again.');
    }
    setDownloading(false);
  };

  // ── Approve / Reject ─────────────────────────────────────────────────────────
  const handleApprove = async () => {
    if (!isDemo) {
      try {
        await apiFetch(`/alerts/${article.id}/approve`, { method: 'POST' });
      } catch {/* swallow */}
    }
    setActionDone('approved');
    onApprove(article.id);
  };

  const handleReject = async () => {
    if (!isDemo) {
      try {
        await apiFetch(`/alerts/${article.id}/reject`, { method: 'POST' });
      } catch {/* swallow */}
    }
    setActionDone('rejected');
    onReject(article.id);
  };

  const project = getProject(projectSlug);
  const PRIMARY = project.primaryColor;
  const SECONDARY = project.secondaryColor;

  return (
    <div className="h-full flex flex-col bg-background border-l border-border overflow-hidden">

      {/* ── Panel header ──────────────────────────────────────────────────── */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-border bg-muted/30 flex-shrink-0">
        <div className="flex items-center gap-2">
          <span className="text-sm font-semibold text-foreground">Client Alert Preview</span>
          {/* Project style indicator */}
          <span
            className="text-[10px] font-bold px-1.5 py-0.5 rounded"
            style={{ background: PRIMARY, color: 'white' }}
          >
            {project.clientName}
          </span>
          {generationSource && (
            <span className="text-xs bg-primary/10 text-primary px-1.5 py-0.5 rounded">
              {generationSource}
            </span>
          )}
        </div>
        <button onClick={onClose} className="text-muted-foreground hover:text-foreground">
          <X className="h-4 w-4" />
        </button>
      </div>

      {/* ── Article metadata strip ────────────────────────────────────────── */}
      <div className="flex-shrink-0 px-4 py-2.5 border-b border-border bg-background">
        <div className="flex items-start gap-2 flex-wrap">
          <Badge variant={article.priority === 'high' ? 'destructive' : 'secondary'} className="text-xs">
            {article.priority.toUpperCase()}
          </Badge>
          <Badge variant="outline" className="text-xs">{article.indication}</Badge>
          <Badge variant="outline" className="text-xs">{article.region}</Badge>
          {content?.news_class && (
            <Badge variant="outline" className="text-xs bg-amber-50">
              {NEWS_CLASS_LABELS[content.news_class] || content.news_class}
            </Badge>
          )}
        </div>
        <div className="mt-1.5 flex items-center gap-1.5 text-xs text-muted-foreground">
          <span>{article.source}</span>
          <span>·</span>
          <span>{article.date}</span>
          <a href={article.source_url} target="_blank" rel="noopener noreferrer" className="ml-0.5">
            <ExternalLink className="h-3 w-3 text-primary" />
          </a>
        </div>
        {article.companies_mentioned.length > 0 && (
          <div className="mt-1 text-xs text-muted-foreground">
            {article.companies_mentioned.join(' · ')}
          </div>
        )}
      </div>

      {/* ── Main scrollable content ───────────────────────────────────────── */}
      <div className="flex-1 overflow-y-auto">

        {/* Not yet generated */}
        {!content && !generating && (
          <div className="flex flex-col items-center justify-center h-full gap-4 p-6 text-center">
            <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
              <span className="text-xl">✦</span>
            </div>
            <div>
              <div className="font-semibold text-foreground mb-1">Generate Client Alert</div>
              <div className="text-sm text-muted-foreground max-w-[240px] leading-snug">
                AI will classify the news, generate {project.labelKeyTakeaways}, strategic {project.labelImplications}, and {project.labelBackground} following the {project.clientName} implications guide.
              </div>
            </div>
            <Button onClick={handleGenerate} className="gap-2">
              <span>✦</span> Generate with GPT-4.1
            </Button>
          </div>
        )}

        {/* Generating */}
        {generating && (
          <div className="flex flex-col items-center justify-center h-full gap-3 p-6 text-center">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
            <div className="text-sm text-muted-foreground">
              Classifying news and generating implications…
            </div>
            <div className="text-xs text-muted-foreground/60">
              Following {project.projectName} implications guide
            </div>
          </div>
        )}

        {/* Generated template */}
        {content && !generating && (
          <div className="pb-4">
            {error && (
              <div className="mx-4 mt-3 p-2 bg-destructive/10 text-destructive text-xs rounded">
                {error}
              </div>
            )}

            {/* ── Template preview — adapts per project style ── */}
            <div
              className="mx-3 mt-3 border border-border rounded overflow-hidden shadow-sm"
              style={{ fontFamily: 'Arial, Helvetica, sans-serif' }}
            >

              {/* ── iAlert style (AUTOANTIBODY) ── */}
              {project.templateStyle === 'ialert' && (
                <>
                  <div className="flex items-center gap-2 px-3 py-2 border-b border-border bg-white">
                    <div className="px-1.5 py-0.5 flex-shrink-0" style={{ background: PRIMARY }}>
                      <span className="text-white font-black text-xs">iAlert</span>
                    </div>
                    <div className="text-[10px] text-muted-foreground leading-tight">
                      Pharmaceutical Associates Ltd<br />Competitive Intelligence &amp; Business Intelligence
                    </div>
                  </div>
                  <div className="flex items-center justify-between px-3 py-1.5" style={{ background: SECONDARY }}>
                    <span className="text-white text-[11px] font-bold tracking-widest uppercase">{project.projectName}</span>
                    <span className="text-white text-[11px] font-bold tracking-wider uppercase">{article.indication}</span>
                  </div>
                  <div className="flex items-start justify-between gap-2 px-3 py-2.5" style={{ background: PRIMARY }}>
                    <span className="text-white text-[13px] font-bold leading-snug">{article.title}</span>
                    <span className="text-white text-[11px] whitespace-nowrap flex-shrink-0 pt-0.5">{article.date}</span>
                  </div>
                  <div className="px-3 py-1.5 bg-white text-[11px]">
                    Source: <a href={article.source_url} target="_blank" rel="noopener noreferrer" style={{ color: PRIMARY }} className="underline">{article.source}</a>
                  </div>
                  <div className="border-t border-border" />
                  <BulletEditor label={project.labelKeyTakeaways} color={PRIMARY} bullets={content.key_takeaways} onChange={setKeyTakeaways} />
                  <div className="border-t border-border" />
                  <BulletEditor label={project.labelImplications} color={PRIMARY} bullets={content.implications} onChange={setImplications} />
                  <div className="border-t border-border">
                    <button className="w-full flex items-center justify-between px-4 py-2" style={{ background: PRIMARY }} onClick={() => setShowBackground((v) => !v)}>
                      <span className="text-white font-bold text-sm">{project.labelBackground}</span>
                      {showBackground ? <ChevronUp className="h-3.5 w-3.5 text-white" /> : <ChevronDown className="h-3.5 w-3.5 text-white" />}
                    </button>
                    {showBackground && <BulletEditor label="" color="transparent" bullets={content.background} onChange={setBackground} />}
                  </div>
                  <div className="px-3 py-1.5 bg-white text-[11px] border-t border-border">
                    Source: <a href={article.source_url} target="_blank" rel="noopener noreferrer" style={{ color: PRIMARY }} className="underline">{article.source}</a>
                  </div>
                </>
              )}

              {/* ── GSK style ── */}
              {project.templateStyle === 'gsk' && (
                <>
                  {/* Orange header */}
                  <div className="px-5 py-5 flex items-center justify-between" style={{ background: PRIMARY }}>
                    <div>
                      <div className="text-white font-bold text-base leading-tight">{project.projectName}</div>
                      <div className="text-white text-xs mt-0.5 opacity-90">Specialty CI alert</div>
                    </div>
                    <div className="text-white font-black text-xl tracking-tight">GSK</div>
                  </div>
                  {/* Intro */}
                  <div className="px-4 py-3 bg-white text-[12px] text-gray-700 border-b border-border">
                    <div className="mb-1 font-medium">{project.greeting || 'Dear team,'}</div>
                    <div className="leading-relaxed">{article.description || article.title}</div>
                    <div className="mt-1.5 text-[11px] text-gray-500">Source: <a href={article.source_url} target="_blank" rel="noopener noreferrer" style={{ color: PRIMARY }} className="underline">{article.source}</a> · {article.date}</div>
                  </div>
                  <div className="h-px mx-4" style={{ background: PRIMARY }} />
                  {/* So What */}
                  <div className="bg-white">
                    <div className="flex items-center gap-2.5 px-4 py-3 border-b border-gray-100">
                      <div className="w-8 h-8 rounded-full flex items-center justify-center text-white text-sm font-bold flex-shrink-0" style={{ background: PRIMARY }}>?</div>
                      <span className="font-bold text-sm" style={{ color: PRIMARY }}>{project.labelImplications}</span>
                    </div>
                    <div className="px-4 pb-3"><BulletEditor label="" color="transparent" bullets={content.implications} onChange={setImplications} /></div>
                  </div>
                  <div className="h-px mx-4" style={{ background: PRIMARY }} />
                  {/* Key Facts */}
                  <div className="bg-white">
                    <div className="flex items-center gap-2.5 px-4 py-3 border-b border-gray-100">
                      <div className="w-8 h-8 rounded-full flex items-center justify-center text-white text-sm flex-shrink-0" style={{ background: PRIMARY }}>🔑</div>
                      <span className="font-bold text-sm" style={{ color: PRIMARY }}>{project.labelKeyTakeaways}</span>
                    </div>
                    <div className="px-4 pb-3"><BulletEditor label="" color="transparent" bullets={content.key_takeaways} onChange={setKeyTakeaways} /></div>
                  </div>
                  <div className="h-px mx-4" style={{ background: PRIMARY }} />
                  {/* More Context */}
                  <div className="bg-white">
                    <button className="w-full flex items-center gap-2.5 px-4 py-3 border-b border-gray-100" onClick={() => setShowBackground((v) => !v)}>
                      <div className="w-8 h-8 rounded-full flex items-center justify-center text-white text-sm flex-shrink-0" style={{ background: PRIMARY }}>💡</div>
                      <span className="font-bold text-sm flex-1 text-left" style={{ color: PRIMARY }}>{project.labelBackground}</span>
                      {showBackground ? <ChevronUp className="h-3.5 w-3.5 text-gray-400" /> : <ChevronDown className="h-3.5 w-3.5 text-gray-400" />}
                    </button>
                    {showBackground && <div className="px-4 pb-3"><BulletEditor label="" color="transparent" bullets={content.background} onChange={setBackground} /></div>}
                  </div>
                  {/* Footer */}
                  <div className="px-4 py-3" style={{ background: PRIMARY }}>
                    <div className="text-white text-[10px] leading-relaxed opacity-90">
                      GCI distribution lists protect GCI of our assets and are restricted to senior leadership and MCTs/MDTs.<br />
                      <em>For internal use only; not to be shared externally.</em>
                    </div>
                  </div>
                </>
              )}

              {/* ── J&J style ── */}
              {project.templateStyle === 'jj' && (
                <div className="bg-white px-4 py-4" style={{ fontFamily: 'Calibri, Arial, sans-serif' }}>
                  {/* Greeting + disclaimer */}
                  <div className="text-[13px] mb-2">{project.greeting || 'Dear all,'}</div>
                  <div className="text-[13px] mb-2">Please see the summary of the news below.</div>
                  {project.disclaimer && (
                    <div className="text-[12px] italic text-gray-600 mb-2">{project.disclaimer}</div>
                  )}
                  <div className="text-[12px] italic text-gray-600 mb-3 leading-relaxed">
                    The below Alert! is a summary of &ldquo;{article.title}&rdquo; based on the following source:{' '}
                    <a href={article.source_url} target="_blank" rel="noopener noreferrer" style={{ color: SECONDARY }} className="underline">{article.source}, {article.date}</a>
                  </div>
                  {/* Red headline */}
                  <div className="text-[14px] font-bold mb-3 leading-snug" style={{ color: PRIMARY }}>{article.title}</div>
                  <div className="border-t border-gray-300 mb-3" />
                  {/* Key Takeaways */}
                  <div className="mb-3">
                    <div className="text-[14px] font-bold underline mb-1.5" style={{ color: SECONDARY }}>{project.labelKeyTakeaways}</div>
                    <BulletEditor label="" color="transparent" bullets={content.key_takeaways} onChange={setKeyTakeaways} />
                  </div>
                  <div className="border-t border-gray-300 mb-3" />
                  {/* Implications */}
                  <div className="mb-3">
                    <div className="text-[14px] font-bold underline mb-1.5" style={{ color: SECONDARY }}>
                      {project.labelImplications}{project.implAudience ? ` (for ${project.implAudience})` : ''}
                    </div>
                    <BulletEditor label="" color="transparent" bullets={content.implications} onChange={setImplications} />
                  </div>
                  <div className="border-t border-gray-300 mb-3" />
                  {/* Summary/Background */}
                  <div className="mb-3">
                    <button className="w-full flex items-center justify-between mb-1.5" onClick={() => setShowBackground((v) => !v)}>
                      <div className="text-[14px] font-bold underline" style={{ color: SECONDARY }}>{project.labelBackground}</div>
                      {showBackground ? <ChevronUp className="h-3.5 w-3.5 text-gray-400" /> : <ChevronDown className="h-3.5 w-3.5 text-gray-400" />}
                    </button>
                    {showBackground && <BulletEditor label="" color="transparent" bullets={content.background} onChange={setBackground} />}
                  </div>
                  <div className="border-t border-gray-300 pt-2 text-[11px] text-gray-500">
                    Source: <a href={article.source_url} target="_blank" rel="noopener noreferrer" style={{ color: SECONDARY }} className="underline">{article.source}, {article.date}</a>
                  </div>
                </div>
              )}

            </div>

            {/* Editing hint */}
            <div className="mx-3 mt-2 text-xs text-muted-foreground">
              Click <Pencil className="h-3 w-3 inline" /> on any section header to edit before downloading.
            </div>
          </div>
        )}
      </div>

      {/* ── Action bar ────────────────────────────────────────────────────── */}
      <div className="flex-shrink-0 border-t border-border p-3 bg-background">

        {actionDone ? (
          <div className={`flex items-center gap-2 justify-center py-2 rounded text-sm font-medium ${
            actionDone === 'approved'
              ? 'bg-success/10 text-success'
              : 'bg-muted text-muted-foreground'
          }`}>
            {actionDone === 'approved'
              ? <><CheckCircle className="h-4 w-4" /> Article approved</>
              : <><XCircle className="h-4 w-4" /> Article rejected</>
            }
          </div>
        ) : (
          <div className="space-y-2">
            {/* Download button — primary CTA when content exists */}
            {content && (
              <Button
                className="w-full gap-2"
                onClick={handleDownloadEml}
                disabled={downloading}
              >
                {downloading
                  ? <Loader2 className="h-4 w-4 animate-spin" />
                  : <Download className="h-4 w-4" />
                }
                {downloading ? 'Preparing…' : 'Open in Outlook (.eml)'}
              </Button>
            )}

            {/* Regenerate */}
            {content && (
              <Button
                variant="outline"
                className="w-full gap-2 text-xs"
                onClick={handleGenerate}
                disabled={generating}
              >
                <RefreshCw className="h-3.5 w-3.5" />
                Regenerate
              </Button>
            )}

            {/* Approve / Reject */}
            <div className="grid grid-cols-2 gap-2">
              <Button
                variant="outline"
                className="gap-1.5 text-success border-success/30 hover:bg-success/10"
                onClick={handleApprove}
              >
                <CheckCircle className="h-4 w-4" /> Approve
              </Button>
              <Button
                variant="outline"
                className="gap-1.5 text-muted-foreground"
                onClick={handleReject}
              >
                <XCircle className="h-4 w-4" /> Reject
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
